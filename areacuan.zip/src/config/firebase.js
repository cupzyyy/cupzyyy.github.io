import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getDatabase } from 'firebase/database'

const firebaseConfig = {
  apiKey: "AIzaSyCf230zCliSZ9EYLByMnmflqw8sOz328Uc",
  authDomain: "database-cupz.firebaseapp.com",
  projectId: "database-cupz",
  storageBucket: "database-cupz.firebasestorage.app",
  messagingSenderId: "343357519412",
  appId: "1:343357519412:web:dce862636c7c459e6a3c61",
  databaseURL: "https://database-cupz-default-rtdb.firebaseio.com"
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getDatabase(app)
export default app
import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import LoadingSpinner from '../UI/LoadingSpinner'

const ProtectedRoute = ({ children, requireAdmin = false }) => {
  const { user, userData, loading } = useAuth()

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  if (requireAdmin) {
    const isAdmin = sessionStorage.getItem('admin_logged') === 'true'
    if (!isAdmin) {
      return <Navigate to="/admin/login" replace />
    }
  }

  return children
}

export default ProtectedRoute
import React from 'react'
import { useLocation } from 'react-router-dom'
import BottomNav from './BottomNav'

const Layout = ({ children }) => {
  const location = useLocation()
  const hideNavPaths = ['/login', '/register', '/payment', '/admin/login', '/admin']
  
  const shouldShowNav = !hideNavPaths.some(path => location.pathname.startsWith(path))

  return (
    <div className="max-w-md mx-auto px-4 py-5 pb-[100px]">
      {children}
      {shouldShowNav && <BottomNav />}
    </div>
  )
}

export default Layout
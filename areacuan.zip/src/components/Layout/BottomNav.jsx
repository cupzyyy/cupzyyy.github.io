import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'

const BottomNav = () => {
  const navigate = useNavigate()
  const location = useLocation()

  const navItems = [
    { key: 'utama', label: 'Utama', icon: 'M3 10L12 3L21 10V20H14V14H10V20H3V10Z', path: '/' },
    { key: 'referral', label: 'Referral', icon: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M9 7a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M23 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75', path: '/referral' },
    { key: 'riwayat', label: 'Riwayat', icon: 'M12 12a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M12 6v6l4 2', path: '/riwayat' },
    { key: 'upgrade', label: 'Upgrade', icon: 'M12 3L14.8 8.5L21 9.3L16.5 13.5L17.8 20L12 16.8L6.2 20L7.5 13.5L3 9.3L9.2 8.5L12 3Z', path: '/upgrade' },
    { key: 'profil', label: 'Profil', icon: 'M12 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M20 21c0-4.7-3.6-8-8-8s-8 3.3-8 8', path: '/profile' }
  ]

  const isActive = (path) => location.pathname === path

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 w-[92%] max-w-[430px] z-[999] bg-white border border-[#E5E5EA] rounded-[30px] shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
      <div className="rounded-full py-3 px-4">
        <div className="flex justify-around">
          {navItems.map((item) => (
            <button
              key={item.key}
              onClick={() => navigate(item.path)}
              className={`text-center transition-colors duration-200 ${isActive(item.path) ? 'text-[#007AFF]' : 'text-[#8E8E93]'}`}
            >
              <div className="flex flex-col items-center gap-1">
                <svg className="w-6 h-6 stroke-current stroke-2 fill-none" viewBox="0 0 24 24">
                  <path d={item.icon} />
                </svg>
                <div className="text-[11px]">{item.label}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

export default BottomNav
import React from 'react'

const LevelBadge = ({ level }) => {
  const levelClasses = {
    FREE: 'bg-[#007AFF] text-white',
    PREMIUM: 'bg-[#AF52DE] text-white',
    VIP: 'bg-gradient-to-r from-[#FF3B30] to-[#FF6B6B] text-white'
  }

  return (
    <span className={`inline-block px-3 py-1 rounded-full text-[11px] font-bold ${levelClasses[level] || levelClasses.FREE}`}>
      {level || 'FREE'}
    </span>
  )
}

export default LevelBadge
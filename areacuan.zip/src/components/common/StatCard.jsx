import React from 'react'
import GlassCard from '../UI/GlassCard'

const StatCard = ({ title, value, icon, className = '' }) => {
  return (
    <GlassCard className="p-4 text-center">
      {icon && <div className="mb-2">{icon}</div>}
      <div className="text-2xl font-black text-[#007AFF]">{value}</div>
      <div className="text-[9px] text-[#8E8E93] uppercase font-bold tracking-wide">{title}</div>
    </GlassCard>
  )
}

export default StatCard
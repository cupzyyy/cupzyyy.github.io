import React from 'react'

const InputIOS = ({ type = 'text', placeholder, value, onChange, className = '', ...props }) => {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      className={`w-full h-[58px] rounded-[20px] px-[18px] outline-none text-[#1C1C1E] bg-[#F9F9FB] border border-[#E5E5EA] focus:border-[#007AFF] focus:shadow-[0_0_0_4px_rgba(0,122,255,0.15)] focus:bg-white transition-all ${className}`}
      {...props}
    />
  )
}

export default InputIOS
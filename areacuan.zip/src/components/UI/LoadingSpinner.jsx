import React from 'react'

const LoadingSpinner = () => {
  return (
    <div className="flex justify-center items-center py-8">
      <div className="w-8 h-8 border-3 border-[#007AFF]/20 border-t-[#007AFF] rounded-full animate-spin"></div>
    </div>
  )
}

export default LoadingSpinner
import React, { useEffect } from 'react'

const Toast = ({ message, type = 'info', onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose()
    }, 3000)

    return () => clearTimeout(timer)
  }, [onClose])

  const bgColor = type === 'success' ? '#34C759' : type === 'error' ? '#FF3B30' : '#1C1C1E'

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '90px',
        left: '50%',
        transform: 'translateX(-50%)',
        background: bgColor,
        color: 'white',
        padding: '12px 20px',
        borderRadius: '60px',
        fontSize: '13px',
        fontWeight: 500,
        zIndex: 1000,
        animation: 'slideUp 0.3s ease',
        whiteSpace: 'nowrap'
      }}
    >
      {message}
    </div>
  )
}

export default Toast
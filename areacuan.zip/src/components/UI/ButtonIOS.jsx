import React from 'react'

const ButtonIOS = ({ children, onClick, variant = 'primary', className = '', disabled = false }) => {
  const variants = {
    primary: 'bg-[#007AFF] text-white shadow-[0_10px_25px_rgba(0,122,255,0.3)]',
    secondary: 'bg-[#F2F2F7] text-[#007AFF]',
    danger: 'bg-red-500/20 text-[#FF3B30] border border-[#FF3B30]/30',
    gradient: 'bg-gradient-to-r from-[#FF3B30] to-[#FF6B6B] text-white shadow-lg shadow-red-500/30'
  }

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`transition-all duration-200 active:scale-97 rounded-2xl font-bold ${variants[variant]} ${className} ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
    >
      {children}
    </button>
  )
}

export default ButtonIOS
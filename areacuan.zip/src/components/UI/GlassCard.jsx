import React from 'react'

const GlassCard = ({ children, className = '', onClick }) => {
  return (
    <div
      className={`bg-white border border-[#E5E5EA] shadow-[0_2px_12px_rgba(0,0,0,0.04)] rounded-[28px] ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  )
}

export default GlassCard
import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { ref, onValue } from 'firebase/database'
import { db } from '../../config/firebase'
import { formatRupiah } from '../../utils/format'
import GlassCard from '../../components/UI/GlassCard'
import ButtonIOS from '../../components/UI/ButtonIOS'
import LevelBadge from '../../components/common/LevelBadge'

const Dashboard = () => {
  const { user, userData, setUserData } = useAuth()
  const [commissions, setCommissions] = useState([])
  const navigate = useNavigate()

  useEffect(() => {
    if (!user) return

    const userRef = ref(db, `users/${user.uid}`)
    const unsubscribeUser = onValue(userRef, (snapshot) => {
      setUserData(snapshot.val())
    })

    const commissionsRef = ref(db, `commissions/${user.uid}`)
    const unsubscribeCommissions = onValue(commissionsRef, (snapshot) => {
      const data = snapshot.val() || {}
      const arr = Object.entries(data).map(([key, val]) => ({ id: key, ...val }))
      arr.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      setCommissions(arr.slice(0, 5))
    })

    return () => {
      unsubscribeUser()
      unsubscribeCommissions()
    }
  }, [user, setUserData])

  const getLevelKomisi = () => {
    const level = userData?.level || 'FREE'
    if (level === 'VIP') return formatRupiah(5000)
    if (level === 'PREMIUM') return formatRupiah(3000)
    return formatRupiah(200)
  }

  return (
    <div className="animate-ios">
      {/* Header */}
      <GlassCard className="p-4 flex justify-between items-center">
        <div>
          <div className="text-xs text-[#007AFF] uppercase tracking-[3px] font-bold">REFCUAN</div>
          <h1 className="text-2xl font-black text-[#1C1C1E]">Halo, {userData?.username || 'Member'} 👋</h1>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-[#F2F2F7] flex items-center justify-center cursor-pointer" onClick={() => navigate('/profile')}>
          <img src="/src/assets/uh.png" className="w-7 h-7 rounded-lg" alt="logo" />
        </div>
      </GlassCard>

      {/* Balance Card */}
      <div className="bg-gradient-to-r from-[#007AFF] to-[#5AC8FA] rounded-[34px] p-6 mt-5 text-white shadow-lg">
        <div className="text-white/70 uppercase text-xs tracking-[3px] font-bold">TOTAL KOMISI</div>
        <h2 className="text-5xl font-black mt-3">{formatRupiah(userData?.saldo || 0)}</h2>
        <div className="grid grid-cols-2 gap-3 mt-5">
          <div className="bg-white/10 rounded-3xl p-4">
            <div className="text-white/70 text-xs">Total Referral</div>
            <div className="font-black text-xl mt-1">{userData?.totalReferrals || 0}</div>
          </div>
          <div className="bg-white/10 rounded-3xl p-4">
            <div className="text-white/70 text-xs">Level Saat Ini</div>
            <div className="mt-1"><LevelBadge level={userData?.level || 'FREE'} /></div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-3 mt-5">
        <ButtonIOS onClick={() => navigate('/withdraw')} variant="secondary" className="flex flex-col items-center p-4">
          <div className="w-12 h-12 rounded-2xl bg-[#F2F2F7] flex items-center justify-center mb-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2"><path d="M12 5v14M5 12l7-7 7 7"/></svg>
          </div>
          <div className="text-sm font-bold text-[#1C1C1E]">Withdraw</div>
        </ButtonIOS>
        <ButtonIOS onClick={() => navigate('/referral')} variant="secondary" className="flex flex-col items-center p-4">
          <div className="w-12 h-12 rounded-2xl bg-[#F2F2F7] flex items-center justify-center mb-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div className="text-sm font-bold text-[#1C1C1E]">Referral</div>
        </ButtonIOS>
        <ButtonIOS onClick={() => navigate('/upgrade')} variant="secondary" className="flex flex-col items-center p-4">
          <div className="w-12 h-12 rounded-2xl bg-[#F2F2F7] flex items-center justify-center mb-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2"><path d="M12 3L14.8 8.5L21 9.3L16.5 13.5L17.8 20L12 16.8L6.2 20L7.5 13.5L3 9.3L9.2 8.5L12 3Z"/></svg>
          </div>
          <div className="text-sm font-bold text-[#1C1C1E]">Upgrade</div>
        </ButtonIOS>
      </div>

      {/* Komisi per Level */}
      <div className="mt-8">
        <h3 className="text-xl font-black text-[#1C1C1E] mb-4">Komisi per Level</h3>
        <GlassCard className="p-5 space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3"><div className="w-3 h-3 rounded-full bg-[#007AFF]"></div><span className="font-bold">FREE</span></div>
            <span className="text-[#34C759] font-bold">{formatRupiah(200)}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3"><div className="w-3 h-3 rounded-full bg-[#AF52DE]"></div><span className="font-bold">PREMIUM</span></div>
            <span className="text-[#34C759] font-bold">{formatRupiah(3000)}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3"><div className="w-3 h-3 rounded-full bg-[#FF3B30]"></div><span className="font-bold">VIP</span></div>
            <span className="text-[#34C759] font-bold">{formatRupiah(5000)}</span>
          </div>
        </GlassCard>
      </div>

      {/* Komisi Terbaru */}
      <div className="mt-8">
        <h3 className="text-xl font-black text-[#1C1C1E] mb-4">Komisi Terbaru</h3>
        <GlassCard className="p-5 space-y-3">
          {commissions.length === 0 ? (
            <div className="text-center text-[#8E8E93] py-4">Belum ada komisi</div>
          ) : (
            commissions.map((comm) => (
              <div key={comm.id} className="flex justify-between items-center py-2 border-b border-[#E5E5EA] last:border-0">
                <div>
                  <div className="font-semibold text-sm text-[#1C1C1E]">{comm.referredEmail || 'User baru'}</div>
                  <div className="text-xs text-[#8E8E93]">{new Date(comm.createdAt).toLocaleDateString('id-ID')}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-[#34C759]">{formatRupiah(comm.amount)}</div>
                  <div className={`text-xs ${comm.level === 'PREMIUM' ? 'text-[#AF52DE]' : comm.level === 'VIP' ? 'text-[#FF3B30]' : 'text-[#007AFF]'}`}>{comm.level || 'FREE'}</div>
                </div>
              </div>
            ))
          )}
        </GlassCard>
      </div>
    </div>
  )
}

export default Dashboard
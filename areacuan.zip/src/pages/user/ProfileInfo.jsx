import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import GlassCard from '../../components/UI/GlassCard'
import LevelBadge from '../../components/common/LevelBadge'

const ProfileInfo = () => {
  const { user, userData } = useAuth()
  const navigate = useNavigate()

  return (
    <div className="max-w-md w-full mx-auto">
      <GlassCard className="p-6 animate-ios">
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => navigate('/profile')} className="w-10 h-10 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <line x1="19" y1="12" x2="5" y2="12"/>
              <polyline points="12 19 5 12 12 5"/>
            </svg>
          </button>
          <h1 className="text-xl font-black text-[#1C1C1E]">Informasi Akun</h1>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center py-3 border-b border-[#E5E5EA]">
            <span className="text-[#8E8E93]">Username</span>
            <span className="font-semibold text-[#1C1C1E]">{userData?.username || '-'}</span>
          </div>
          <div className="flex justify-between items-center py-3 border-b border-[#E5E5EA]">
            <span className="text-[#8E8E93]">Email</span>
            <span className="font-semibold text-[#1C1C1E]">{user?.email || '-'}</span>
          </div>
          <div className="flex justify-between items-center py-3 border-b border-[#E5E5EA]">
            <span className="text-[#8E8E93]">Nomor Telepon</span>
            <span className="font-semibold text-[#1C1C1E]">{userData?.phone || '-'}</span>
          </div>
          <div className="flex justify-between items-center py-3 border-b border-[#E5E5EA]">
            <span className="text-[#8E8E93]">Level</span>
            <LevelBadge level={userData?.level || 'FREE'} />
          </div>
          <div className="flex justify-between items-center py-3">
            <span className="text-[#8E8E93]">Bergabung Sejak</span>
            <span className="font-semibold text-[#1C1C1E]">
              {userData?.createdAt ? new Date(userData.createdAt).toLocaleDateString('id-ID') : '-'}
            </span>
          </div>
        </div>

        <button onClick={() => navigate('/profile')} className="block w-full mt-6 py-3 bg-[#007AFF] rounded-2xl font-bold text-white text-center">
          Kembali
        </button>
      </GlassCard>
    </div>
  )
}

export default ProfileInfo
import React, { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { auth } from '../../config/firebase'
import { signOut } from 'firebase/auth'
import Swal from 'sweetalert2'
import GlassCard from '../../components/UI/GlassCard'
import ButtonIOS from '../../components/UI/ButtonIOS'
import LevelBadge from '../../components/common/LevelBadge'
import { formatRupiah } from '../../utils/format'

const Profile = () => {
  const { user, userData } = useAuth()
  const navigate = useNavigate()

  const handleLogout = async () => {
    const result = await Swal.fire({
      title: 'Keluar Akun?',
      text: 'Yakin ingin keluar?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#007AFF',
      confirmButtonText: 'Ya',
      cancelButtonText: 'Batal',
      background: '#FFFFFF',
      color: '#1C1C1E'
    })
    if (result.isConfirmed) {
      await signOut(auth)
      navigate('/login')
    }
  }

  return (
    <div className="animate-ios">
      <GlassCard className="p-4 flex justify-between items-center">
        <div>
          <div className="text-xs text-[#007AFF] uppercase tracking-[3px] font-bold">PROFIL</div>
          <h1 className="text-xl font-black text-[#1C1C1E]">{userData?.username || '-'}</h1>
          <div className="text-xs text-[#8E8E93] mt-1">{user?.email || '-'}</div>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-[#F2F2F7] flex items-center justify-center">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
            <circle cx="12" cy="8" r="4"/>
            <path d="M20 21c0-4.7-3.6-8-8-8s-8 3.3-8 8"/>
          </svg>
        </div>
      </GlassCard>

      <GlassCard className="p-5 mt-5">
        <div className="text-[#007AFF] uppercase text-xs tracking-[3px] font-bold">TOTAL KOMISI</div>
        <h2 className="text-3xl font-black text-[#1C1C1E] mt-2">{formatRupiah(userData?.saldo || 0)}</h2>
      </GlassCard>

      <div className="space-y-3 mt-5">
        <Link to="/profile/info" className="bg-white border border-[#E5E5EA] rounded-2xl p-4 flex items-center gap-3 active:scale-98 transition-all block">
          <div className="w-12 h-12 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <circle cx="12" cy="8" r="4"/>
              <path d="M20 21c0-4.7-3.6-8-8-8s-8 3.3-8 8"/>
            </svg>
          </div>
          <div className="flex-1">
            <div className="font-bold text-[#1C1C1E]">Informasi Akun</div>
            <div className="text-xs text-[#8E8E93]">Lihat data diri Anda</div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8E8E93" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
        </Link>

        <Link to="/profile/bank" className="bg-white border border-[#E5E5EA] rounded-2xl p-4 flex items-center gap-3 active:scale-98 transition-all block">
          <div className="w-12 h-12 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <rect x="2" y="5" width="20" height="14" rx="2"/>
              <line x1="2" y1="10" x2="22" y2="10"/>
            </svg>
          </div>
          <div className="flex-1">
            <div className="font-bold text-[#1C1C1E]">Data Rekening</div>
            <div className="text-xs text-[#8E8E93]">Informasi rekening Anda</div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8E8E93" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
        </Link>

        <Link to="/profile/password" className="bg-white border border-[#E5E5EA] rounded-2xl p-4 flex items-center gap-3 active:scale-98 transition-all block">
          <div className="w-12 h-12 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <rect x="3" y="11" width="18" height="11" rx="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </div>
          <div className="flex-1">
            <div className="font-bold text-[#1C1C1E]">Ganti Password</div>
            <div className="text-xs text-[#8E8E93]">Perbarui password akun</div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8E8E93" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
        </Link>

        <Link to="/profile/referral-code" className="bg-white border border-[#E5E5EA] rounded-2xl p-4 flex items-center gap-3 active:scale-98 transition-all block">
          <div className="w-12 h-12 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
            </svg>
          </div>
          <div className="flex-1">
            <div className="font-bold text-[#1C1C1E]">Kode Referral</div>
            <div className="text-xs text-[#8E8E93]">Bagikan kode Anda</div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8E8E93" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
        </Link>
      </div>

      <ButtonIOS onClick={handleLogout} variant="danger" className="w-full mt-6 py-3.5">
        Keluar
      </ButtonIOS>
    </div>
  )
}

export default Profile
import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { formatRupiah } from '../../utils/format'
import GlassCard from '../../components/UI/GlassCard'
import ButtonIOS from '../../components/UI/ButtonIOS'
import LevelBadge from '../../components/common/LevelBadge'

const Upgrade = () => {
  const { userData } = useAuth()
  const navigate = useNavigate()
  const [currentLevel, setCurrentLevel] = useState('FREE')
  const [currentKomisi, setCurrentKomisi] = useState(200)

  useEffect(() => {
    if (userData) {
      const level = userData.level || 'FREE'
      setCurrentLevel(level)
      if (level === 'PREMIUM') setCurrentKomisi(3000)
      else if (level === 'VIP') setCurrentKomisi(5000)
      else setCurrentKomisi(200)
    }
  }, [userData])

  const handleUpgrade = (plan) => {
    navigate(`/payment?plan=${plan}`)
  }

  const isUpgraded = (plan) => {
    if (plan === 'premium' && (currentLevel === 'PREMIUM' || currentLevel === 'VIP')) return true
    if (plan === 'vip' && currentLevel === 'VIP') return true
    return false
  }

  return (
    <div className="animate-ios">
      {/* Current Level */}
      <GlassCard className="p-5 mb-5">
        <h3 className="font-bold text-[#1C1C1E] mb-2">Level Saat Ini</h3>
        <div className="flex justify-between items-center">
          <div>
            <div className="text-2xl font-black text-[#1C1C1E]">{currentLevel}</div>
            <div className="text-sm text-[#8E8E93]">Komisi: {formatRupiah(currentKomisi)} / referral</div>
          </div>
          <LevelBadge level={currentLevel} />
        </div>
      </GlassCard>

      {/* Premium Plan */}
      <GlassCard className={`p-5 mb-5 ${isUpgraded('premium') ? 'opacity-60' : ''}`}>
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="font-bold text-xl text-[#1C1C1E]">PREMIUM</h3>
            <p className="text-sm text-[#8E8E93]">Komisi Rp3.000 / referral</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-[#007AFF]">{formatRupiah(30000)}</div>
            <div className="text-xs text-[#8E8E93]">Sekali bayar</div>
          </div>
        </div>
        <ul className="space-y-2 mb-4">
          <li className="flex items-center gap-2 text-sm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Komisi Rp3.000 per referral</li>
          <li className="flex items-center gap-2 text-sm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Akses lifetime</li>
          <li className="flex items-center gap-2 text-sm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Withdraw prioritas</li>
        </ul>
        <ButtonIOS
          onClick={() => handleUpgrade('premium')}
          variant="primary"
          className="w-full py-3"
          disabled={isUpgraded('premium')}
        >
          {isUpgraded('premium') ? 'Sudah Diupgrade' : `Upgrade ke PREMIUM - ${formatRupiah(30000)}`}
        </ButtonIOS>
      </GlassCard>

      {/* VIP Plan */}
      <GlassCard className={`p-5 mb-5 ${isUpgraded('vip') ? 'opacity-60' : ''}`}>
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="font-bold text-xl text-[#1C1C1E]">VIP</h3>
            <p className="text-sm text-[#8E8E93]">Komisi Rp5.000 / referral</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-[#007AFF]">{formatRupiah(50000)}</div>
            <div className="text-xs text-[#8E8E93]">Sekali bayar</div>
          </div>
        </div>
        <ul className="space-y-2 mb-4">
          <li className="flex items-center gap-2 text-sm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Komisi Rp5.000 per referral</li>
          <li className="flex items-center gap-2 text-sm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Akses lifetime</li>
          <li className="flex items-center gap-2 text-sm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Withdraw prioritas tertinggi</li>
          <li className="flex items-center gap-2 text-sm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg> Badge eksklusif</li>
        </ul>
        <ButtonIOS
          onClick={() => handleUpgrade('vip')}
          variant="gradient"
          className="w-full py-3"
          disabled={isUpgraded('vip')}
        >
          {isUpgraded('vip') ? 'Sudah Diupgrade' : `Upgrade ke VIP - ${formatRupiah(50000)}`}
        </ButtonIOS>
      </GlassCard>

      {/* Comparison */}
      <GlassCard className="p-5 mb-5">
        <h3 className="font-bold text-[#1C1C1E] mb-3">Perbandingan Level</h3>
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-[#8E8E93]">Komisi</span>
            <span>FREE: {formatRupiah(200)}</span>
            <span>PREMIUM: {formatRupiah(3000)}</span>
            <span>VIP: {formatRupiah(5000)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#8E8E93]">Biaya Upgrade</span>
            <span>-</span>
            <span>{formatRupiah(30000)}</span>
            <span>{formatRupiah(50000)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#8E8E93]">Withdraw Priority</span>
            <span>Normal</span>
            <span>Tinggi</span>
            <span>Tertinggi</span>
          </div>
        </div>
        <p className="text-xs text-[#8E8E93] text-center mt-3">*Upgrade sekali bayar via QRIS, berlaku lifetime</p>
      </GlassCard>
    </div>
  )
}

export default Upgrade
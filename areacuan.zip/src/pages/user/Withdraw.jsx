import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { ref, update, get, push, set } from 'firebase/database'
import { db } from '../../config/firebase'
import Swal from 'sweetalert2'
import { formatRupiah } from '../../utils/format'
import GlassCard from '../../components/UI/GlassCard'
import InputIOS from '../../components/UI/InputIOS'
import ButtonIOS from '../../components/UI/ButtonIOS'

const Withdraw = () => {
  const { user, userData } = useAuth()
  const [amount, setAmount] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const calculateFee = (amt) => {
    const amountNum = parseInt(amt) || 0
    const fee = Math.floor(amountNum * 0.1)
    const net = amountNum - fee
    return { fee, net }
  }

  const { fee, net } = calculateFee(amount)

  const setAmountQuick = (val) => {
    setAmount(val.toString())
  }

  const handleSubmit = async () => {
    const amountNum = parseInt(amount)
    if (isNaN(amountNum) || amountNum < 50000) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Minimal withdraw Rp50.000!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }
    if (amountNum > 10000000) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Maksimal Rp10.000.000/hari!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }
    if ((userData?.saldo || 0) < amountNum) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Saldo tidak mencukupi!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }

    const confirm = await Swal.fire({
      title: 'Konfirmasi Withdraw',
      html: `
        <div class="text-left">
          <div class="flex justify-between"><span>Jumlah</span><span class="font-bold">${formatRupiah(amountNum)}</span></div>
          <div class="flex justify-between"><span>Admin 10%</span><span class="font-bold text-[#FF9500]">${formatRupiah(fee)}</span></div>
          <div class="flex justify-between pt-2 border-t"><span>Diterima</span><span class="font-bold text-[#34C759]">${formatRupiah(net)}</span></div>
        </div>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#007AFF',
      confirmButtonText: 'Ya, Ajukan',
      cancelButtonText: 'Batal',
      background: '#FFFFFF',
      color: '#1C1C1E'
    })

    if (!confirm.isConfirmed) return

    setLoading(true)

    try {
      const wid = 'WD-' + Date.now()
      const now = new Date().toISOString()

      await set(ref(db, `withdrawals/${user.uid}/${wid}`), {
        id: wid,
        amount: amountNum,
        fee,
        netAmount: net,
        bankType: userData.bankType,
        accountNumber: userData.accountNumber,
        accountName: userData.accountName,
        status: 'pending',
        createdAt: now,
        username: userData.username,
        email: userData.email
      })

      await set(ref(db, `allWithdrawals/${wid}`), {
        id: wid,
        userId: user.uid,
        username: userData.username,
        email: userData.email,
        amount: amountNum,
        fee,
        netAmount: net,
        bankType: userData.bankType,
        accountNumber: userData.accountNumber,
        accountName: userData.accountName,
        status: 'pending',
        createdAt: now
      })

      await update(ref(db, `users/${user.uid}`), {
        saldo: (userData.saldo || 0) - amountNum
      })

      Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Withdraw diajukan, menunggu persetujuan admin.', background: '#FFFFFF', color: '#1C1C1E' })
      setAmount('')
    } catch (error) {
      Swal.fire({ icon: 'error', title: 'Error', text: error.message, background: '#FFFFFF', color: '#1C1C1E' })
    } finally {
      setLoading(false)
    }
  }

  if (!userData?.bankType) {
    return (
      <GlassCard className="p-8 text-center">
        <div className="w-20 h-20 rounded-2xl bg-[#F2F2F7] flex items-center justify-center mx-auto mb-4">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
            <rect x="2" y="5" width="20" height="14" rx="2"/>
            <line x1="2" y1="10" x2="22" y2="10"/>
          </svg>
        </div>
        <h3 className="font-bold text-lg mb-2">Data Rekening Belum Diisi</h3>
        <p className="text-sm text-[#8E8E93] mb-4">Silakan lengkapi data rekening Anda terlebih dahulu</p>
        <ButtonIOS onClick={() => navigate('/profile/bank')} variant="primary" className="w-full py-3">
          Lengkapi Data Rekening
        </ButtonIOS>
      </GlassCard>
    )
  }

  return (
    <div className="animate-ios">
      <GlassCard className="p-4 mb-4">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-[#007AFF] uppercase text-xs tracking-[3px] font-bold">TOTAL KOMISI</div>
            <div className="text-2xl font-black text-[#1C1C1E] mt-1">{formatRupiah(userData?.saldo || 0)}</div>
          </div>
          <button onClick={() => navigate('/riwayat')} className="bg-[#F2F2F7] px-4 py-2 rounded-xl text-[#8E8E93] text-sm font-bold">
            Riwayat
          </button>
        </div>
      </GlassCard>

      <GlassCard className="p-5">
        <h2 className="text-xl font-black text-[#1C1C1E] mb-1">Tarik Komisi</h2>
        <p className="text-xs text-[#8E8E93] mb-4">Minimal Rp50.000 - Biaya admin 10%</p>

        {/* Bank Info */}
        <div className="bg-[#F2F2F7] rounded-2xl p-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
                <rect x="2" y="5" width="20" height="14" rx="2"/>
                <line x1="2" y1="10" x2="22" y2="10"/>
              </svg>
            </div>
            <div>
              <div className="font-bold text-[#1C1C1E]">{userData?.bankType || '-'}</div>
              <div className="text-sm font-mono text-[#8E8E93]">{userData?.accountNumber || '-'}</div>
            </div>
          </div>
          <div className="mt-2 text-sm">
            <span className="text-[#8E8E93]">Nama Pemilik:</span>
            <span className="font-bold text-[#1C1C1E] ml-1">{userData?.accountName || '-'}</span>
          </div>
        </div>

        {/* Amount Input */}
        <InputIOS
          type="number"
          placeholder="Masukkan nominal"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="mb-3"
        />

        {/* Quick Amount */}
        <div className="grid grid-cols-4 gap-2 mb-4">
          {[50000, 100000, 500000, 1000000].map((val) => (
            <button key={val} onClick={() => setAmountQuick(val)} className="bg-[#F2F2F7] py-2 rounded-xl text-sm text-[#1C1C1E]">
              {val >= 1000000 ? `${val/1000000}JT` : `${val/1000}rb`}
            </button>
          ))}
        </div>

        {/* Fee Info */}
        <div className="bg-[#F2F2F7] rounded-2xl p-4 mb-4">
          <div className="flex justify-between py-2">
            <span className="text-[#8E8E93]">Jumlah Withdraw</span>
            <span className="font-bold text-[#1C1C1E]">{formatRupiah(amount)}</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-[#8E8E93]">Biaya Admin (10%)</span>
            <span className="font-bold text-[#FF9500]">{formatRupiah(fee)}</span>
          </div>
          <div className="flex justify-between py-2 pt-2 border-t border-[#E5E5EA] mt-1">
            <span className="text-[#8E8E93]">Total Diterima</span>
            <span className="text-xl font-bold text-[#34C759]">{formatRupiah(net)}</span>
          </div>
        </div>

        <ButtonIOS onClick={handleSubmit} variant="primary" className="w-full py-3.5" disabled={loading}>
          {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto"></div> : 'Ajukan Withdraw'}
        </ButtonIOS>
      </GlassCard>
    </div>
  )
}

export default Withdraw
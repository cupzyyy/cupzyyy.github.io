import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { auth } from '../../config/firebase'
import { updatePassword, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth'
import Swal from 'sweetalert2'
import GlassCard from '../../components/UI/GlassCard'
import InputIOS from '../../components/UI/InputIOS'
import ButtonIOS from '../../components/UI/ButtonIOS'

const ProfilePassword = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Semua field wajib diisi!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }
    if (newPassword !== confirmPassword) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Password baru tidak cocok!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }
    if (newPassword.length < 6) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Password minimal 6 karakter!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }

    setLoading(true)

    try {
      const credential = EmailAuthProvider.credential(user.email, currentPassword)
      await reauthenticateWithCredential(user, credential)
      await updatePassword(user, newPassword)
      
      Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Password berhasil diubah!', timer: 1500, showConfirmButton: false, background: '#FFFFFF', color: '#1C1C1E' })
      setTimeout(() => navigate('/profile'), 1500)
    } catch (error) {
      const msg = error.code === 'auth/wrong-password' ? 'Password saat ini salah!' : 'Gagal mengubah password'
      Swal.fire({ icon: 'error', title: 'Gagal!', text: msg, background: '#FFFFFF', color: '#1C1C1E' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md w-full mx-auto">
      <GlassCard className="p-6 animate-ios">
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => navigate('/profile')} className="w-10 h-10 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <line x1="19" y1="12" x2="5" y2="12"/>
              <polyline points="12 19 5 12 12 5"/>
            </svg>
          </button>
          <h1 className="text-xl font-black text-[#1C1C1E]">Ganti Password</h1>
        </div>

        <div className="space-y-4">
          <InputIOS
            type="password"
            placeholder="Password Saat Ini"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
          />
          <InputIOS
            type="password"
            placeholder="Password Baru (min. 6 karakter)"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
          <InputIOS
            type="password"
            placeholder="Konfirmasi Password Baru"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>

        <ButtonIOS onClick={handleSubmit} variant="primary" className="w-full mt-6 py-3" disabled={loading}>
          {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto"></div> : 'Simpan Password Baru'}
        </ButtonIOS>

        <button onClick={() => navigate('/profile')} className="block w-full mt-3 py-3 bg-[#F2F2F7] rounded-2xl font-bold text-[#8E8E93] text-center">
          Batal
        </button>
      </GlassCard>
    </div>
  )
}

export default ProfilePassword
import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import Swal from 'sweetalert2'
import GlassCard from '../../components/UI/GlassCard'

const ProfileReferralCode = () => {
  const { userData } = useAuth()
  const navigate = useNavigate()

  const copyReferralCode = () => {
    const code = userData?.referralCode
    if (code) {
      navigator.clipboard.writeText(code)
      Swal.fire({ icon: 'success', title: 'Tersalin!', text: 'Kode referral disalin!', timer: 1500, showConfirmButton: false, background: '#FFFFFF', color: '#1C1C1E' })
    }
  }

  const copyReferralLink = () => {
    const link = userData?.referralLink
    if (link) {
      navigator.clipboard.writeText(link)
      Swal.fire({ icon: 'success', title: 'Tersalin!', text: 'Link referral disalin!', timer: 1500, showConfirmButton: false, background: '#FFFFFF', color: '#1C1C1E' })
    }
  }

  return (
    <div className="max-w-md w-full mx-auto">
      <GlassCard className="p-6 animate-ios">
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => navigate('/profile')} className="w-10 h-10 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <line x1="19" y1="12" x2="5" y2="12"/>
              <polyline points="12 19 5 12 12 5"/>
            </svg>
          </button>
          <h1 className="text-xl font-black text-[#1C1C1E]">Kode Referral</h1>
        </div>

        <div className="text-center">
          <p className="text-[#8E8E93] text-sm mb-3">Bagikan kode ini ke teman Anda</p>
          <div className="font-mono text-3xl font-black tracking-[4px] text-[#007AFF] bg-[#F2F2F7] py-5 rounded-2xl">
            {userData?.referralCode || '-'}
          </div>
          <p className="text-xs text-[#8E8E93] mt-3 break-all">{userData?.referralLink || '-'}</p>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={copyReferralCode} className="flex-1 py-3 bg-[#007AFF] rounded-2xl font-bold text-white shadow-lg shadow-blue-500/30">
            Salin Kode
          </button>
          <button onClick={copyReferralLink} className="flex-1 py-3 bg-[#F2F2F7] rounded-2xl font-bold text-[#007AFF]">
            Salin Link
          </button>
        </div>

        <div className="mt-5 p-4 bg-[#F2F2F7] rounded-xl">
          <p className="text-xs text-[#8E8E93] text-center">
            Setiap teman yang mendaftar dengan kode Anda, Anda akan mendapatkan komisi sesuai level
          </p>
        </div>

        <button onClick={() => navigate('/profile')} className="block w-full mt-5 py-3 bg-[#F2F2F7] rounded-2xl font-bold text-[#8E8E93] text-center">
          Kembali
        </button>
      </GlassCard>
    </div>
  )
}

export default ProfileReferralCode
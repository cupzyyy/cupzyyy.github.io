import React, { useState, useEffect } from 'react'
import { useAuth } from '../../context/AuthContext'
import { ref, onValue } from 'firebase/database'
import { db } from '../../config/firebase'
import { formatRupiah, formatDateTime } from '../../utils/format'
import GlassCard from '../../components/UI/GlassCard'

const Riwayat = () => {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('komisi')
  const [commissions, setCommissions] = useState([])
  const [withdrawals, setWithdrawals] = useState([])

  useEffect(() => {
    if (!user) return

    const commissionsRef = ref(db, `commissions/${user.uid}`)
    const unsubscribeCommissions = onValue(commissionsRef, (snapshot) => {
      const data = snapshot.val() || {}
      const arr = Object.entries(data).map(([key, val]) => ({ id: key, ...val }))
      arr.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      setCommissions(arr)
    })

    const withdrawalsRef = ref(db, `withdrawals/${user.uid}`)
    const unsubscribeWithdrawals = onValue(withdrawalsRef, (snapshot) => {
      const data = snapshot.val() || {}
      const arr = Object.entries(data).map(([key, val]) => ({ id: key, ...val }))
      arr.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      setWithdrawals(arr)
    })

    return () => {
      unsubscribeCommissions()
      unsubscribeWithdrawals()
    }
  }, [user])

  const getStatusStyle = (status) => {
    if (status === 'success') return 'text-[#34C759] bg-[#34C759]/10'
    if (status === 'pending') return 'text-[#FF9500] bg-[#FF9500]/10'
    return 'text-[#FF3B30] bg-[#FF3B30]/10'
  }

  return (
    <div className="animate-ios">
      <GlassCard className="p-5 mb-5">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-[#007AFF] uppercase text-xs tracking-[3px] font-bold">TOTAL KOMISI</div>
            <div className="text-3xl font-black text-[#1C1C1E] mt-1">{formatRupiah(0)}</div>
          </div>
          <button onClick={() => window.location.href = '/withdraw'} className="bg-[#007AFF] px-5 py-2.5 rounded-xl text-white text-sm font-bold shadow-md">
            Withdraw
          </button>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 bg-[#F2F2F7] p-1 rounded-full mb-5">
        <button
          onClick={() => setActiveTab('komisi')}
          className={`flex-1 py-2.5 rounded-full text-sm font-bold transition-all ${activeTab === 'komisi' ? 'bg-[#007AFF] text-white' : 'text-[#8E8E93]'}`}
        >
          Komisi
        </button>
        <button
          onClick={() => setActiveTab('withdraw')}
          className={`flex-1 py-2.5 rounded-full text-sm font-bold transition-all ${activeTab === 'withdraw' ? 'bg-[#007AFF] text-white' : 'text-[#8E8E93]'}`}
        >
          Withdraw
        </button>
      </div>

      {/* Komisi List */}
      {activeTab === 'komisi' && (
        <div className="space-y-3">
          {commissions.length === 0 ? (
            <div className="text-center py-12">
              <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="#C6C6C8" strokeWidth="1.5" className="mx-auto mb-3">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
              </svg>
              <p className="text-[#8E8E93] text-sm">Belum ada riwayat komisi</p>
            </div>
          ) : (
            commissions.map((comm) => (
              <div key={comm.id} className="bg-white border border-[#E5E5EA] rounded-2xl p-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#34C759]/10 flex items-center justify-center">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2">
                    <path d="M12 2L15 9H22L16 14L19 21L12 16.5L5 21L8 14L2 9H9L12 2Z"/>
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="font-bold text-[#34C759]">+{formatRupiah(comm.amount)}</div>
                  <div className="text-xs text-[#8E8E93]">Komisi dari {comm.referredEmail || 'User baru'}</div>
                  <div className="text-[10px] text-[#C6C6C8] mt-0.5">{formatDateTime(comm.createdAt)}</div>
                </div>
                <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${
                  comm.level === 'PREMIUM' ? 'text-[#AF52DE] bg-[#AF52DE]/10' :
                  comm.level === 'VIP' ? 'text-[#FF3B30] bg-[#FF3B30]/10' :
                  'text-[#007AFF] bg-[#007AFF]/10'
                }`}>
                  {comm.level || 'FREE'}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {/* Withdraw List */}
      {activeTab === 'withdraw' && (
        <div className="space-y-3">
          {withdrawals.length === 0 ? (
            <div className="text-center py-12">
              <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="#C6C6C8" strokeWidth="1.5" className="mx-auto mb-3">
                <path d="M12 5v14M5 12l7-7 7 7"/>
              </svg>
              <p className="text-[#8E8E93] text-sm">Belum ada riwayat withdraw</p>
            </div>
          ) : (
            withdrawals.map((wd) => (
              <div key={wd.id} className="bg-white border border-[#E5E5EA] rounded-2xl p-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#007AFF]/10 flex items-center justify-center">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
                    <path d="M12 5v14M5 12l7-7 7 7"/>
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="font-bold text-[#1C1C1E]">{formatRupiah(wd.amount || 0)}</div>
                  <div className="text-xs text-[#8E8E93]">{wd.bankType || 'Bank Transfer'}</div>
                  <div className="text-[10px] text-[#C6C6C8] mt-0.5">{formatDateTime(wd.createdAt)}</div>
                </div>
                <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${getStatusStyle(wd.status)}`}>
                  {wd.status === 'success' ? 'Sukses' : wd.status === 'pending' ? 'Pending' : 'Ditolak'}
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}

export default Riwayat
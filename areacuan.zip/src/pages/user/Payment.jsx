import React, { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { ref, update, push, set } from 'firebase/database'
import { db } from '../../config/firebase'
import Swal from 'sweetalert2'
import { formatRupiah } from '../../utils/format'
import GlassCard from '../../components/UI/GlassCard'
import ButtonIOS from '../../components/UI/ButtonIOS'

const Payment = () => {
  const [searchParams] = useSearchParams()
  const { user } = useAuth()
  const navigate = useNavigate()
  const plan = searchParams.get('plan') || 'premium'
  const price = plan === 'premium' ? 30000 : 50000

  const [orderId, setOrderId] = useState(null)
  const [qrImage, setQrImage] = useState(null)
  const [paymentUrl, setPaymentUrl] = useState(null)
  const [expiredAt, setExpiredAt] = useState(null)
  const [timeLeft, setTimeLeft] = useState(1800) // 30 menit
  const [status, setStatus] = useState('pending')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    createOrder()
  }, [])

  useEffect(() => {
    if (expiredAt) {
      const timer = setInterval(() => {
        const diff = new Date(expiredAt) - new Date()
        if (diff <= 0) {
          clearInterval(timer)
          setTimeLeft(0)
          setStatus('expired')
        } else {
          setTimeLeft(Math.floor(diff / 1000))
        }
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [expiredAt])

  useEffect(() => {
    if (orderId && status === 'pending') {
      const interval = setInterval(checkStatus, 3000)
      return () => clearInterval(interval)
    }
  }, [orderId, status])

  const createOrder = async () => {
    try {
      const response = await fetch('/api/create-payment.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: price,
          user_id: user?.uid,
          email: user?.email,
          type: 'upgrade',
          plan_id: plan
        })
      })
      const result = await response.json()
      if (result.ok) {
        setOrderId(result.order_id)
        setQrImage(result.qr_image)
        setPaymentUrl(result.payment_url)
        setExpiredAt(result.expired_at)
        setStatus('pending')
      } else {
        throw new Error(result.error || 'Gagal membuat order')
      }
    } catch (error) {
      Swal.fire({ icon: 'error', title: 'Gagal!', text: error.message, background: '#FFFFFF', color: '#1C1C1E' })
        .then(() => navigate('/upgrade'))
    } finally {
      setLoading(false)
    }
  }

  const checkStatus = async () => {
    if (!orderId) return
    try {
      const response = await fetch('/api/check-status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: orderId })
      })
      const result = await response.json()
      if (result.ok && result.status === 'paid') {
        setStatus('paid')
        const newLevel = plan.toUpperCase()
        await update(ref(db, `users/${user.uid}`), { level: newLevel })
        
        const upgradeId = 'UPG-' + Date.now() + '-' + Math.random().toString(36).substr(2, 6)
        await set(ref(db, `upgrades/${user.uid}/${upgradeId}`), {
          id: upgradeId,
          order_id: orderId,
          fromLevel: 'FREE',
          toLevel: newLevel,
          price: price,
          createdAt: new Date().toISOString()
        })
        
        Swal.fire({ icon: 'success', title: 'Berhasil! 🎉', text: `Selamat! Level Anda sekarang ${newLevel}!`, background: '#FFFFFF', color: '#1C1C1E', confirmButtonColor: '#007AFF' })
          .then(() => navigate('/'))
      } else if (result.ok && result.status === 'expired') {
        setStatus('expired')
      }
    } catch (error) {
      console.error('Polling error:', error)
    }
  }

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="w-8 h-8 border-3 border-[#007AFF]/20 border-t-[#007AFF] rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto">
      <GlassCard className="p-6 animate-ios">
        <div className="flex items-center gap-3 mb-5">
          <button onClick={() => navigate('/upgrade')} className="w-10 h-10 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <line x1="19" y1="12" x2="5" y2="12"/>
              <polyline points="12 19 5 12 12 5"/>
            </svg>
          </button>
          <h1 className="text-xl font-black text-[#1C1C1E]">Pembayaran Upgrade</h1>
        </div>

        <div className="text-center mb-6">
          <div className="inline-block w-20 h-20 rounded-2xl bg-gradient-to-br from-[#007AFF] to-[#5AC8FA] flex items-center justify-center mx-auto shadow-lg">
            <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <path d="M12 3L14.8 8.5L21 9.3L16.5 13.5L17.8 20L12 16.8L6.2 20L7.5 13.5L3 9.3L9.2 8.5L12 3Z"/>
            </svg>
          </div>
          <h2 className="text-2xl font-black text-[#1C1C1E] mt-3">{plan.toUpperCase()}</h2>
          <p className="text-[#8E8E93]">Upgrade level untuk komisi lebih besar</p>
        </div>

        <div className="bg-[#F2F2F7] rounded-2xl p-4 mb-6">
          <div className="flex justify-between py-2">
            <span className="text-[#8E8E93]">Paket</span>
            <span className="font-bold text-[#1C1C1E]">{plan.toUpperCase()}</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-[#8E8E93]">Harga</span>
            <span className="font-bold text-[#007AFF] text-xl">{formatRupiah(price)}</span>
          </div>
          <div className="flex justify-between py-2 pt-2 border-t border-[#E5E5EA] mt-1">
            <span className="text-[#8E8E93]">Total Pembayaran</span>
            <span className="font-bold text-[#34C759] text-xl">{formatRupiah(price)}</span>
          </div>
        </div>

        <div className="text-center mb-5">
          <p className="text-sm text-[#8E8E93] mb-3">Scan QRIS berikut untuk membayar</p>
          {qrImage && <img src={qrImage} alt="QR Code" className="w-48 h-48 mx-auto rounded-2xl shadow-lg" />}
          {paymentUrl && (
            <div className="mt-2">
              <a href={paymentUrl} target="_blank" className="text-[#007AFF] text-xs underline">Klik jika QR tidak muncul</a>
            </div>
          )}
          <div className="text-sm font-mono bg-[#F2F2F7] p-3 rounded-xl mb-2 break-all">{orderId}</div>
          <div className={`text-sm font-semibold ${timeLeft === 0 ? 'text-[#FF3B30]' : 'text-[#FF9500]'}`}>
            Sisa waktu: {formatTime(timeLeft)}
          </div>
        </div>

        <div className="text-center text-sm text-[#8E8E93] mb-5 p-3 bg-[#F2F2F7] rounded-xl">
          {status === 'pending' && 'Menunggu pembayaran...'}
          {status === 'paid' && '✅ Pembayaran berhasil! Sedang memproses upgrade...'}
          {status === 'expired' && '⏰ Waktu pembayaran habis! Silakan coba lagi.'}
        </div>

        <ButtonIOS onClick={() => navigate('/upgrade')} variant="secondary" className="w-full py-3">
          Batal
        </ButtonIOS>
      </GlassCard>
    </div>
  )
}

export default Payment
import React, { useState, useEffect } from 'react'
import { useAuth } from '../../context/AuthContext'
import { ref, get } from 'firebase/database'
import { db } from '../../config/firebase'
import { formatRupiah } from '../../utils/format'
import Swal from 'sweetalert2'
import GlassCard from '../../components/UI/GlassCard'
import ButtonIOS from '../../components/UI/ButtonIOS'

const Referral = () => {
  const { userData } = useAuth()
  const [referrals, setReferrals] = useState([])
  const [totalReferrals, setTotalReferrals] = useState(0)

  useEffect(() => {
    if (userData?.referralCode) {
      loadReferrals()
    }
  }, [userData])

  const loadReferrals = async () => {
    const usersRef = ref(db, 'users')
    const snapshot = await get(usersRef)
    const users = snapshot.val() || {}
    const refList = []
    for (const uid in users) {
      if (users[uid].referredBy === userData.referralCode) {
        refList.push({
          username: users[uid].username || 'User',
          referredAt: users[uid].referredAt || users[uid].createdAt
        })
      }
    }
    setReferrals(refList)
    setTotalReferrals(refList.length)
  }

  const getLevelKomisi = () => {
    const level = userData?.level || 'FREE'
    if (level === 'VIP') return formatRupiah(5000)
    if (level === 'PREMIUM') return formatRupiah(3000)
    return formatRupiah(200)
  }

  const copyReferral = () => {
    const link = userData?.referralLink
    if (link) {
      navigator.clipboard.writeText(link)
      Swal.fire({ icon: 'success', title: 'Tersalin!', toast: true, position: 'top-end', showConfirmButton: false, timer: 2000, background: '#FFFFFF', color: '#1C1C1E' })
    }
  }

  const shareWhatsApp = () => {
    const link = userData?.referralLink
    window.open(`https://wa.me/?text=${encodeURIComponent('Gabung Refcuan: ' + link)}`, '_blank')
  }

  const shareTelegram = () => {
    const link = userData?.referralLink
    window.open(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=Gabung Refcuan`, '_blank')
  }

  const shareFacebook = () => {
    const link = userData?.referralLink
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(link)}`, '_blank')
  }

  return (
    <div className="animate-ios">
      {/* Saldo Card */}
      <GlassCard className="p-4 mb-4">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-[#007AFF] uppercase text-xs tracking-[3px] font-bold">TOTAL KOMISI</div>
            <div className="text-2xl font-black text-[#1C1C1E] mt-1">{formatRupiah(userData?.saldo || 0)}</div>
          </div>
        </div>
      </GlassCard>

      {/* Referral Card */}
      <GlassCard className="p-5 text-center mb-4">
        <div className="w-12 h-12 rounded-2xl bg-[#F2F2F7] flex items-center justify-center mx-auto mb-3">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
            <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
            <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
          </svg>
        </div>
        <h3 className="font-bold text-lg text-[#1C1C1E]">Kode Referral Anda</h3>
        <div className="font-mono text-2xl font-black tracking-[4px] text-[#007AFF] bg-[#F2F2F7] py-3 rounded-2xl my-3">
          {userData?.referralCode || '-'}
        </div>
        <div className="bg-[#F2F2F7] rounded-xl p-2 text-[10px] text-[#8E8E93] break-all font-mono mb-3">
          {userData?.referralLink || '-'}
        </div>
        <ButtonIOS onClick={copyReferral} variant="primary" className="w-full py-3">
          Salin Link Undangan
        </ButtonIOS>
      </GlassCard>

      {/* Share Buttons */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <button onClick={shareWhatsApp} className="bg-[#25D366] py-3 rounded-2xl font-bold text-white text-sm">WhatsApp</button>
        <button onClick={shareTelegram} className="bg-[#0088cc] py-3 rounded-2xl font-bold text-white text-sm">Telegram</button>
        <button onClick={shareFacebook} className="bg-[#1877f2] py-3 rounded-2xl font-bold text-white text-sm">Facebook</button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <GlassCard className="p-3 text-center rounded-2xl">
          <div className="text-xl font-black text-[#007AFF]">{totalReferrals}</div>
          <div className="text-[9px] text-[#8E8E93]">TOTAL REFERRAL</div>
        </GlassCard>
        <GlassCard className="p-3 text-center rounded-2xl">
          <div className="text-xl font-black text-[#34C759]">{formatRupiah(userData?.totalKomisi || 0)}</div>
          <div className="text-[9px] text-[#8E8E93]">KOMISI</div>
        </GlassCard>
        <GlassCard className="p-3 text-center rounded-2xl">
          <div className="text-xl font-black text-[#FF9500]">{getLevelKomisi()}</div>
          <div className="text-[9px] text-[#8E8E93]">PER REFERRAL</div>
        </GlassCard>
      </div>

      {/* Daftar Referral */}
      <h3 className="text-sm font-bold text-[#1C1C1E] mb-3">Daftar Referral</h3>
      <GlassCard className="overflow-hidden rounded-2xl">
        <table className="w-full">
          <thead className="bg-[#F2F2F7]">
            <tr>
              <th className="p-3 text-left text-[10px] text-[#8E8E93]">MEMBER</th>
              <th className="p-3 text-left text-[10px] text-[#8E8E93]">TANGGAL</th>
            </tr>
          </thead>
          <tbody>
            {referrals.length === 0 ? (
              <tr><td colSpan="2" className="p-6 text-center text-[#8E8E93] text-sm">Belum ada referral</td></tr>
            ) : (
              referrals.map((ref, idx) => (
                <tr key={idx} className="border-t border-[#E5E5EA]">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#007AFF] to-[#5AC8FA] flex items-center justify-center text-white font-bold text-xs">
                        {ref.username.charAt(0).toUpperCase()}
                      </div>
                      <span className="text-sm text-[#1C1C1E]">{ref.username}</span>
                    </div>
                  </td>
                  <td className="p-3 text-xs text-[#8E8E93]">{ref.referredAt ? new Date(ref.referredAt).toLocaleDateString('id-ID') : '-'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </GlassCard>

      {/* Info Bonus */}
      <div className="mt-4 p-4 bg-[#F2F2F7] rounded-2xl">
        <div className="flex items-center gap-2 mb-1">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2"><path d="M12 2L15 9H22L16 14L19 21L12 16.5L5 21L8 14L2 9H9L12 2Z"/></svg>
          <span className="text-xs font-bold text-[#007AFF]">Bonus Komisi</span>
        </div>
        <p className="text-[10px] text-[#8E8E93]">FREE: Rp200 | PREMIUM: Rp3.000 | VIP: Rp5.000 per referral</p>
      </div>
    </div>
  )
}

export default Referral
import React from 'react'
import { useNavigate } from 'react-router-dom'
import GlassCard from '../../components/UI/GlassCard'
import ButtonIOS from '../../components/UI/ButtonIOS'

const About = () => {
  const navigate = useNavigate()

  return (
    <div className="animate-ios">
      <div className="flex justify-between items-center mb-4">
        <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-xl bg-[#F2F2F7] flex items-center justify-center">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
            <line x1="19" y1="12" x2="5" y2="12"/>
            <polyline points="12 19 5 12 12 5"/>
          </svg>
        </button>
        <div className="w-12 h-12 rounded-2xl bg-[#F2F2F7] flex items-center justify-center">
          <img src="/src/assets/uh.png" className="w-7 h-7 rounded-lg" alt="logo" />
        </div>
      </div>

      {/* Hero */}
      <GlassCard className="p-6 mb-5 text-center">
        <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#007AFF] to-[#5AC8FA] flex items-center justify-center mx-auto mb-3 shadow-lg">
          <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
            <path d="M4 16L9 11L13 15L20 8"/>
            <path d="M16 8H20V12"/>
          </svg>
        </div>
        <h1 className="text-2xl font-black text-[#1C1C1E]">Refcuan</h1>
        <p className="text-[#8E8E93] text-sm mt-1">Platform Referral Terpercaya</p>
        <div className="flex justify-center gap-2 mt-3">
          <span className="bg-[#F2F2F7] px-3 py-1 rounded-full text-[10px] font-bold text-[#007AFF]">AMAN</span>
          <span className="bg-[#F2F2F7] px-3 py-1 rounded-full text-[10px] font-bold text-[#007AFF]">WITHDRAW CEPAT</span>
        </div>
      </GlassCard>

      {/* Company Profile */}
      <GlassCard className="p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
            <rect x="4" y="2" width="16" height="20" rx="2"/>
            <line x1="8" y1="6" x2="16" y2="6"/>
          </svg>
          <h2 className="text-xs uppercase tracking-[2px] text-[#8E8E93] font-black">PROFIL PERUSAHAAN</h2>
        </div>
        <p className="text-[#3A3A3C] text-sm leading-relaxed mb-3">
          <span className="font-bold text-[#007AFF]">Refcuan</span> adalah platform referral yang berdiri sejak tahun 2024. 
          Kami berkomitmen untuk memberikan layanan referral yang <span className="font-semibold">aman, transparan, dan menguntungkan</span> 
          bagi seluruh masyarakat Indonesia.
        </p>
        <p className="text-[#8E8E93] text-sm leading-relaxed">
          Dengan mengusung teknologi terkini, Refcuan telah dipercaya oleh lebih dari <span className="font-bold text-[#007AFF]">10.000+ member</span> 
          aktif di seluruh Indonesia.
        </p>
      </GlassCard>

      {/* Visi Misi */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <GlassCard className="p-4">
          <div className="w-10 h-10 rounded-xl bg-[#F2F2F7] flex items-center justify-center mb-2">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
              <circle cx="12" cy="12" r="3"/>
            </svg>
          </div>
          <h3 className="font-bold text-sm text-[#1C1C1E] mb-1">VISI</h3>
          <p className="text-[#8E8E93] text-xs">Menjadi platform referral terdepan di Indonesia.</p>
        </GlassCard>
        <GlassCard className="p-4">
          <div className="w-10 h-10 rounded-xl bg-[#F2F2F7] flex items-center justify-center mb-2">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <path d="M12 6v6l4 2"/>
            </svg>
          </div>
          <h3 className="font-bold text-sm text-[#1C1C1E] mb-1">MISI</h3>
          <p className="text-[#8E8E93] text-xs">Sistem referral transparan & pembayaran cepat.</p>
        </GlassCard>
      </div>

      {/* Statistik */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <GlassCard className="p-3 text-center">
          <div className="text-2xl font-black text-[#007AFF]">10K+</div>
          <div className="text-[9px] text-[#8E8E93]">MEMBER AKTIF</div>
        </GlassCard>
        <GlassCard className="p-3 text-center">
          <div className="text-2xl font-black text-[#007AFF]">Rp5K</div>
          <div className="text-[9px] text-[#8E8E93]">MAX KOMISI</div>
        </GlassCard>
        <GlassCard className="p-3 text-center">
          <div className="text-2xl font-black text-[#007AFF]">24/7</div>
          <div className="text-[9px] text-[#8E8E93]">CUSTOMER SERVICE</div>
        </GlassCard>
      </div>

      {/* Keunggulan */}
      <GlassCard className="p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
            <path d="M12 3L20 7V12C20 17 16.5 20.5 12 22C7.5 20.5 4 17 4 12V7L12 3Z"/>
          </svg>
          <h2 className="text-xs uppercase tracking-[2px] text-[#8E8E93] font-black">KEUNGGULAN KAMI</h2>
        </div>
        <div className="space-y-3">
          <div className="flex gap-3">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <div>
              <p className="font-semibold text-sm text-[#1C1C1E]">Keamanan Terjamin</p>
              <p className="text-[#8E8E93] text-xs">Enkripsi SSL & proteksi data berlapis</p>
            </div>
          </div>
          <div className="flex gap-3">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <polyline points="12 6 12 12 16 14"/>
            </svg>
            <div>
              <p className="font-semibold text-sm text-[#1C1C1E]">Komisi Otomatis</p>
              <p className="text-[#8E8E93] text-xs">Komisi masuk otomatis saat referral daftar</p>
            </div>
          </div>
          <div className="flex gap-3">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34C759" strokeWidth="2">
              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
            </svg>
            <div>
              <p className="font-semibold text-sm text-[#1C1C1E]">Support 24/7</p>
              <p className="text-[#8E8E93] text-xs">Via Telegram & WhatsApp</p>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Hubungi Kami */}
      <GlassCard className="p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <h2 className="text-xs uppercase tracking-[2px] text-[#8E8E93] font-black">HUBUNGI KAMI</h2>
        </div>
        <div className="space-y-3">
          <a href="https://t.me/csrefcuan" target="_blank" className="flex items-center gap-3 p-3 bg-[#F2F2F7] rounded-xl">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>
            </svg>
            <div>
              <p className="font-semibold text-sm text-[#1C1C1E]">Telegram Support</p>
              <p className="text-[#8E8E93] text-xs">@csrefcuan</p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#C6C6C8" strokeWidth="2" className="ml-auto">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </a>
          <a href="mailto:support@refcuan.co.id" className="flex items-center gap-3 p-3 bg-[#F2F2F7] rounded-xl">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
              <rect x="2" y="4" width="20" height="16" rx="2"/>
              <path d="m22 7-10 7L2 7"/>
            </svg>
            <div>
              <p className="font-semibold text-sm text-[#1C1C1E]">Email Support</p>
              <p className="text-[#8E8E93] text-xs">support@refcuan.co.id</p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#C6C6C8" strokeWidth="2" className="ml-auto">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </a>
        </div>
      </GlassCard>

      <div className="text-center py-4">
        <p className="text-[10px] text-[#C6C6C8]">© 2024-2026 Refcuan. All Rights Reserved.</p>
      </div>
    </div>
  )
}

export default About
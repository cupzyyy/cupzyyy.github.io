import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ref, get } from 'firebase/database'
import { db } from '../../config/firebase'
import { formatRupiah } from '../../utils/format'

const AdminDashboard = () => {
  const navigate = useNavigate()
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalKomisi: 0,
    totalReferral: 0,
    pendingWithdraw: 0,
    free: 0,
    premium: 0,
    vip: 0
  })
  const [recentActivities, setRecentActivities] = useState([])

  useEffect(() => {
    loadDashboard()
    const interval = setInterval(loadDashboard, 30000)
    return () => clearInterval(interval)
  }, [])

  const loadDashboard = async () => {
    const usersSnap = await get(ref(db, 'users'))
    const users = usersSnap.val() || {}
    
    let totalUsers = 0, totalKomisi = 0, totalReferral = 0, free = 0, premium = 0, vip = 0
    for (const uid in users) {
      totalUsers++
      totalKomisi += users[uid].totalKomisi || 0
      totalReferral += users[uid].totalReferrals || 0
      const lvl = users[uid].level || 'FREE'
      if (lvl === 'FREE') free++
      else if (lvl === 'PREMIUM') premium++
      else if (lvl === 'VIP') vip++
    }

    const wdSnap = await get(ref(db, 'allWithdrawals'))
    const withdrawals = wdSnap.val() || {}
    let pending = 0
    for (const id in withdrawals) {
      if (withdrawals[id].status === 'pending') pending++
    }

    setStats({
      totalUsers,
      totalKomisi,
      totalReferral,
      pendingWithdraw: pending,
      free, premium, vip
    })

    // Recent Activities
    const activities = []
    for (const uid in users) {
      if (users[uid].createdAt) {
        activities.push({
          type: 'register',
          username: users[uid].username || users[uid].email,
          time: users[uid].createdAt
        })
      }
    }
    for (const id in withdrawals) {
      if (withdrawals[id].createdAt) {
        activities.push({
          type: 'withdraw',
          username: withdrawals[id].username,
          amount: withdrawals[id].amount,
          status: withdrawals[id].status,
          time: withdrawals[id].createdAt
        })
      }
    }
    activities.sort((a, b) => new Date(b.time) - new Date(a.time))
    setRecentActivities(activities.slice(0, 10))
  }

  const maxLevel = Math.max(stats.free, stats.premium, stats.vip, 1)

  return (
    <div className="bg-black min-h-screen">
      <div className="flex">
        {/* Sidebar */}
        <div className="fixed left-0 top-0 w-[260px] h-screen bg-black/80 backdrop-blur-2xl border-r border-white/10 z-50">
          <div className="p-6 border-b border-white/10 flex items-center gap-3">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
              <path d="M4 16L9 11L13 15L20 8"/>
              <path d="M16 8H20V12"/>
            </svg>
            <span className="text-lg font-black">Refcuan Admin</span>
          </div>
          <div className="py-4">
            <a onClick={() => navigate('/admin')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 10L12 3L21 10V20H14V14H10V20H3V10Z"/></svg>
              <span>Dashboard</span>
            </a>
            <a onClick={() => navigate('/admin/users')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              <span>Kelola User</span>
            </a>
            <a onClick={() => navigate('/admin/withdrawals')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              <span>Kelola Withdraw</span>
            </a>
            <a onClick={() => navigate('/admin/settings')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span>Settings</span>
            </a>
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-5 border-t border-white/10">
            <div className="bg-red-500/20 px-3 py-2 rounded-full text-center">
              <span className="text-[10px] font-bold text-red-400">ADMIN REFCUAN</span>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="ml-[260px] w-full">
          <div className="sticky top-0 bg-black/60 backdrop-blur-xl border-b border-white/10 p-4 flex justify-between items-center z-50">
            <span className="font-bold text-lg">Dashboard Admin</span>
            <button onClick={() => { sessionStorage.removeItem('admin_logged'); navigate('/admin/login'); }} className="bg-red-500/20 px-4 py-2 rounded-xl text-red-400 text-sm font-bold">
              Keluar
            </button>
          </div>

          <div className="p-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-4 gap-5 mb-6">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                <div className="text-3xl font-black text-blue-400">{stats.totalUsers}</div>
                <div className="text-[11px] text-gray-500 mt-2 uppercase">Total User</div>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                <div className="text-3xl font-black text-blue-400">{formatRupiah(stats.totalKomisi)}</div>
                <div className="text-[11px] text-gray-500 mt-2 uppercase">Total Komisi</div>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                <div className="text-3xl font-black text-blue-400">{stats.totalReferral}</div>
                <div className="text-[11px] text-gray-500 mt-2 uppercase">Total Referral</div>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                <div className="text-3xl font-black text-yellow-400">{stats.pendingWithdraw}</div>
                <div className="text-[11px] text-gray-500 mt-2 uppercase">Pending Withdraw</div>
              </div>
            </div>

            {/* Level Distribution */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-6">
              <h2 className="font-bold mb-4 flex items-center gap-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
                  <path d="M12 2L15 9H22L16 14L19 21L12 16.5L5 21L8 14L2 9H9L12 2Z"/>
                </svg>
                Distribusi Level Member
              </h2>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1"><span>FREE</span><span>{stats.free}</span></div>
                  <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(stats.free / maxLevel) * 100}%` }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1"><span>PREMIUM</span><span>{stats.premium}</span></div>
                  <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 rounded-full" style={{ width: `${(stats.premium / maxLevel) * 100}%` }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1"><span>VIP</span><span>{stats.vip}</span></div>
                  <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500 rounded-full" style={{ width: `${(stats.vip / maxLevel) * 100}%` }}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Activities */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="font-bold mb-4 flex items-center gap-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
                  <circle cx="12" cy="12" r="10"/>
                  <polyline points="12 6 12 12 16 14"/>
                </svg>
                Recent Activities
              </h2>
              <div className="space-y-2">
                {recentActivities.length === 0 ? (
                  <div className="text-center text-gray-500 py-4">Loading...</div>
                ) : (
                  recentActivities.map((act, idx) => (
                    <div key={idx} className="flex justify-between items-center py-2 border-b border-white/10">
                      <div>
                        {act.type === 'register' ? (
                          <span className="text-green-400">✓</span>
                        ) : (
                          <span className="text-blue-400">💰</span>
                        )} {act.type === 'register' ? `User baru: ${act.username}` : `Withdraw: ${act.username} - ${formatRupiah(act.amount)}`}
                      </div>
                      <div className={`text-xs ${act.status === 'pending' ? 'text-yellow-400' : 'text-gray-500'}`}>
                        {new Date(act.time).toLocaleString()}
                        {act.status === 'pending' && ' - Pending'}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AdminDashboard
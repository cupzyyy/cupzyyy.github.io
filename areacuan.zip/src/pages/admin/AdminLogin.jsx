import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Swal from 'sweetalert2'

const ADMIN_PASSWORD = 'adminrefcuan123'

const AdminLogin = () => {
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (!password) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Password wajib diisi!', background: '#1c1c1e', color: 'white' })
      return
    }
    
    setLoading(true)
    
    setTimeout(() => {
      if (password === ADMIN_PASSWORD) {
        sessionStorage.setItem('admin_logged', 'true')
        navigate('/admin')
      } else {
        Swal.fire({ icon: 'error', title: 'Akses Ditolak', text: 'Password admin salah!', background: '#1c1c1e', color: 'white' })
        setPassword('')
      }
      setLoading(false)
    }, 800)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-5 bg-black">
      <div className="fixed inset-0 overflow-hidden -z-10">
        <div className="absolute w-[450px] h-[450px] bg-blue-500/20 blur-[140px] rounded-full -top-32 -left-32"></div>
        <div className="absolute w-[450px] h-[450px] bg-cyan-500/10 blur-[140px] rounded-full bottom-0 right-0"></div>
      </div>

      <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-3xl max-w-sm w-full p-8 animate-ios">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mx-auto shadow-[0_0_40px_rgba(10,132,255,0.4)]">
            <svg width="38" height="38" viewBox="0 0 24 24" fill="none">
              <path d="M4 16L9 11L13 15L20 8" stroke="white" strokeWidth="2.5"/>
              <path d="M16 8H20V12" stroke="white" strokeWidth="2.5"/>
            </svg>
          </div>
          <h1 className="text-3xl font-black mt-4 text-white">Admin Panel</h1>
          <p className="text-gray-400 mt-2">Refcuan Administrator</p>
          <div className="inline-block bg-red-500/20 px-3 py-1 rounded-full mt-3">
            <span className="text-[10px] font-bold text-red-400">RESTRICTED ACCESS</span>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <input
            type="password"
            placeholder="Password Admin"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full h-[58px] rounded-2xl px-5 outline-none text-white bg-white/5 border border-white/10 focus:border-blue-500/50 focus:shadow-[0_0_0_4px_rgba(10,132,255,0.15)]"
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full h-14 rounded-2xl font-semibold bg-gradient-to-r from-blue-600 to-cyan-500 shadow-[0_10px_35px_rgba(10,132,255,0.4)] mt-4 transition-all duration-200 active:scale-97"
          >
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto"></div> : 'Masuk ke Dashboard'}
          </button>
        </form>

        <div className="text-center mt-6">
          <a href="/" className="text-gray-500 text-sm hover:text-blue-400 transition">← Kembali ke Website</a>
        </div>
      </div>
    </div>
  )
}

export default AdminLogin
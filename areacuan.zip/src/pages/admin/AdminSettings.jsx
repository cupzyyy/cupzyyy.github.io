import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ref, get, update } from 'firebase/database'
import { db } from '../../config/firebase'
import Swal from 'sweetalert2'

const AdminSettings = () => {
  const navigate = useNavigate()
  const [settings, setSettings] = useState({
    komisiFREE: 200,
    komisiPREMIUM: 3000,
    komisiVIP: 5000,
    minWithdraw: 50000,
    maxWithdrawPerDay: 10000000,
    feeAdmin: 10
  })

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    const snap = await get(ref(db, 'system_settings'))
    const data = snap.val() || {}
    setSettings({
      komisiFREE: data.komisiFREE || 200,
      komisiPREMIUM: data.komisiPREMIUM || 3000,
      komisiVIP: data.komisiVIP || 5000,
      minWithdraw: data.minWithdraw || 50000,
      maxWithdrawPerDay: data.maxWithdrawPerDay || 10000000,
      feeAdmin: data.feeAdmin || 10
    })
  }

  const saveKomisi = async () => {
    await update(ref(db, 'system_settings'), {
      komisiFREE: settings.komisiFREE,
      komisiPREMIUM: settings.komisiPREMIUM,
      komisiVIP: settings.komisiVIP
    })
    Swal.fire({ icon: 'success', title: 'Berhasil!', timer: 1500, showConfirmButton: false, background: '#1c1c1e', color: 'white' })
  }

  const saveWithdrawSettings = async () => {
    await update(ref(db, 'system_settings'), {
      minWithdraw: settings.minWithdraw,
      maxWithdrawPerDay: settings.maxWithdrawPerDay,
      feeAdmin: settings.feeAdmin
    })
    Swal.fire({ icon: 'success', title: 'Berhasil!', timer: 1500, showConfirmButton: false, background: '#1c1c1e', color: 'white' })
  }

  return (
    <div className="bg-black min-h-screen">
      <div className="flex">
        {/* Sidebar */}
        <div className="fixed left-0 top-0 w-[260px] h-screen bg-black/80 backdrop-blur-2xl border-r border-white/10 z-50">
          <div className="p-6 border-b border-white/10 flex items-center gap-3">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
              <path d="M4 16L9 11L13 15L20 8"/>
              <path d="M16 8H20V12"/>
            </svg>
            <span className="text-lg font-black">Refcuan Admin</span>
          </div>
          <div className="py-4">
            <a onClick={() => navigate('/admin')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 10L12 3L21 10V20H14V14H10V20H3V10Z"/></svg>
              <span>Dashboard</span>
            </a>
            <a onClick={() => navigate('/admin/users')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              <span>Kelola User</span>
            </a>
            <a onClick={() => navigate('/admin/withdrawals')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              <span>Kelola Withdraw</span>
            </a>
            <a onClick={() => navigate('/admin/settings')} className="flex items-center gap-3 px-6 py-3 text-white bg-blue-500/10 border-l-3 border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span>Settings</span>
            </a>
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-5 border-t border-white/10">
            <div className="bg-red-500/20 px-3 py-2 rounded-full text-center">
              <span className="text-[10px] font-bold text-red-400">ADMIN REFCUAN</span>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="ml-[260px] w-full">
          <div className="sticky top-0 bg-black/60 backdrop-blur-xl border-b border-white/10 p-4 flex justify-between items-center z-50">
            <span className="font-bold text-lg">Settings</span>
            <button onClick={() => { sessionStorage.removeItem('admin_logged'); navigate('/admin/login'); }} className="bg-red-500/20 px-4 py-2 rounded-xl text-red-400 text-sm font-bold">
              Keluar
            </button>
          </div>

          <div className="p-6">
            {/* Komisi Settings */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-6">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
                  <path d="M12 2L15 9H22L16 14L19 21L12 16.5L5 21L8 14L2 9H9L12 2Z"/>
                </svg>
                Komisi per Level
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs text-gray-500">FREE (Rp)</label>
                  <input
                    type="number"
                    value={settings.komisiFREE}
                    onChange={(e) => setSettings({ ...settings, komisiFREE: parseInt(e.target.value) || 0 })}
                    className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">PREMIUM (Rp)</label>
                  <input
                    type="number"
                    value={settings.komisiPREMIUM}
                    onChange={(e) => setSettings({ ...settings, komisiPREMIUM: parseInt(e.target.value) || 0 })}
                    className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">VIP (Rp)</label>
                  <input
                    type="number"
                    value={settings.komisiVIP}
                    onChange={(e) => setSettings({ ...settings, komisiVIP: parseInt(e.target.value) || 0 })}
                    className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mt-1"
                  />
                </div>
              </div>
              <button onClick={saveKomisi} className="bg-blue-500 px-6 py-3 rounded-xl font-bold mt-4">
                Simpan Komisi
              </button>
            </div>

            {/* Withdraw Settings */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
                  <rect x="2" y="5" width="20" height="14" rx="2"/>
                  <line x1="2" y1="10" x2="22" y2="10"/>
                </svg>
                Withdraw Limits
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs text-gray-500">Minimal Withdraw (Rp)</label>
                  <input
                    type="number"
                    value={settings.minWithdraw}
                    onChange={(e) => setSettings({ ...settings, minWithdraw: parseInt(e.target.value) || 0 })}
                    className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">Maksimal per Hari (Rp)</label>
                  <input
                    type="number"
                    value={settings.maxWithdrawPerDay}
                    onChange={(e) => setSettings({ ...settings, maxWithdrawPerDay: parseInt(e.target.value) || 0 })}
                    className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mt-1"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-500">Fee Admin (%)</label>
                <input
                  type="number"
                  value={settings.feeAdmin}
                  onChange={(e) => setSettings({ ...settings, feeAdmin: parseInt(e.target.value) || 0 })}
                  className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mt-1"
                />
              </div>
              <button onClick={saveWithdrawSettings} className="bg-blue-500 px-6 py-3 rounded-xl font-bold mt-4">
                Simpan Setting Withdraw
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AdminSettings
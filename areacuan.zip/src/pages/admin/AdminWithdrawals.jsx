import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ref, get, update } from 'firebase/database'
import { db } from '../../config/firebase'
import Swal from 'sweetalert2'
import { formatRupiah, formatDateTime } from '../../utils/format'

const AdminWithdrawals = () => {
  const navigate = useNavigate()
  const [withdrawals, setWithdrawals] = useState([])
  const [activeTab, setActiveTab] = useState('pending')

  useEffect(() => {
    loadWithdrawals()
  }, [])

  const loadWithdrawals = async () => {
    const snap = await get(ref(db, 'allWithdrawals'))
    const data = snap.val() || {}
    const list = Object.entries(data).map(([id, wd]) => ({ id, ...wd }))
    list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    setWithdrawals(list)
  }

  const filteredWithdrawals = withdrawals.filter(w => w.status === activeTab)

  const approveWithdraw = async (wdId, userId) => {
    const result = await Swal.fire({
      title: 'Setujui Withdraw?',
      text: 'Yakin ingin menyetujui withdraw ini?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#22C55E',
      confirmButtonText: 'Ya',
      cancelButtonText: 'Batal',
      background: '#1c1c1e',
      color: 'white'
    })
    if (!result.isConfirmed) return

    await update(ref(db, `allWithdrawals/${wdId}`), { status: 'success', processedAt: new Date().toISOString() })
    if (userId) {
      await update(ref(db, `withdrawals/${userId}/${wdId}`), { status: 'success', processedAt: new Date().toISOString() })
    }
    await loadWithdrawals()
    Swal.fire({ icon: 'success', title: 'Berhasil!', timer: 1500, showConfirmButton: false, background: '#1c1c1e', color: 'white' })
  }

  const rejectWithdraw = async (wdId, userId, amount) => {
    const result = await Swal.fire({
      title: 'Tolak Withdraw?',
      text: 'Saldo akan dikembalikan ke user.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#FF3B30',
      confirmButtonText: 'Ya, Tolak',
      cancelButtonText: 'Batal',
      background: '#1c1c1e',
      color: 'white'
    })
    if (!result.isConfirmed) return

    if (userId && amount) {
      const saldoSnap = await get(ref(db, `users/${userId}/saldo`))
      await update(ref(db, `users/${userId}/saldo`), (saldoSnap.val() || 0) + amount)
    }

    await update(ref(db, `allWithdrawals/${wdId}`), { status: 'rejected', processedAt: new Date().toISOString() })
    if (userId) {
      await update(ref(db, `withdrawals/${userId}/${wdId}`), { status: 'rejected', processedAt: new Date().toISOString() })
    }
    await loadWithdrawals()
    Swal.fire({ icon: 'success', title: 'Berhasil!', timer: 1500, showConfirmButton: false, background: '#1c1c1e', color: 'white' })
  }

  return (
    <div className="bg-black min-h-screen">
      <div className="flex">
        {/* Sidebar */}
        <div className="fixed left-0 top-0 w-[260px] h-screen bg-black/80 backdrop-blur-2xl border-r border-white/10 z-50">
          <div className="p-6 border-b border-white/10 flex items-center gap-3">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
              <path d="M4 16L9 11L13 15L20 8"/>
              <path d="M16 8H20V12"/>
            </svg>
            <span className="text-lg font-black">Refcuan Admin</span>
          </div>
          <div className="py-4">
            <a onClick={() => navigate('/admin')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 10L12 3L21 10V20H14V14H10V20H3V10Z"/></svg>
              <span>Dashboard</span>
            </a>
            <a onClick={() => navigate('/admin/users')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              <span>Kelola User</span>
            </a>
            <a onClick={() => navigate('/admin/withdrawals')} className="flex items-center gap-3 px-6 py-3 text-white bg-blue-500/10 border-l-3 border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              <span>Kelola Withdraw</span>
            </a>
            <a onClick={() => navigate('/admin/settings')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span>Settings</span>
            </a>
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-5 border-t border-white/10">
            <div className="bg-red-500/20 px-3 py-2 rounded-full text-center">
              <span className="text-[10px] font-bold text-red-400">ADMIN REFCUAN</span>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="ml-[260px] w-full">
          <div className="sticky top-0 bg-black/60 backdrop-blur-xl border-b border-white/10 p-4 flex justify-between items-center z-50">
            <span className="font-bold text-lg">Kelola Withdraw</span>
            <button onClick={() => { sessionStorage.removeItem('admin_logged'); navigate('/admin/login'); }} className="bg-red-500/20 px-4 py-2 rounded-xl text-red-400 text-sm font-bold">
              Keluar
            </button>
          </div>

          <div className="p-6">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              {/* Tabs */}
              <div className="flex gap-2 bg-white/5 rounded-full p-1 mb-6">
                {['pending', 'success', 'rejected'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-1 py-2 rounded-full text-sm font-bold transition-all ${
                      activeTab === tab ? 'bg-blue-500 text-white' : 'text-gray-400'
                    }`}
                  >
                    {tab === 'pending' ? 'Pending' : tab === 'success' ? 'Approved' : 'Rejected'}
                  </button>
                ))}
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/10">
                      <th className="p-3 text-left text-[11px] text-gray-500">User</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Bank/E-Wallet</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Nomor</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Nominal</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Fee(10%)</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Diterima</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Tanggal</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredWithdrawals.length === 0 ? (
                      <tr>
                        <td colSpan="8" className="p-8 text-center text-gray-500">Tidak ada data</td>
                      </tr>
                    ) : (
                      filteredWithdrawals.map((wd) => {
                        const fee = Math.floor((wd.amount || 0) * 0.1)
                        const net = (wd.amount || 0) - fee
                        return (
                          <tr key={wd.id} className="border-b border-white/5">
                            <td className="p-3">
                              <strong>{wd.username || 'User'}</strong><br />
                              <span className="text-xs text-gray-500">{wd.email || '-'}</span>
                            </td>
                            <td className="p-3">{wd.bankType || '-'}</td>
                            <td className="p-3 font-mono">{wd.accountNumber || '-'}</td>
                            <td className="p-3 font-mono text-red-400">{formatRupiah(wd.amount || 0)}</td>
                            <td className="p-3 font-mono text-yellow-400">{formatRupiah(fee)}</td>
                            <td className="p-3 font-mono text-green-400">{formatRupiah(net)}</td>
                            <td className="p-3 text-xs">{formatDateTime(wd.createdAt)}</td>
                            <td className="p-3">
                              {wd.status === 'pending' && (
                                <div className="flex gap-2">
                                  <button onClick={() => approveWithdraw(wd.id, wd.userId)} className="bg-green-500/20 text-green-400 px-3 py-1 rounded-lg text-xs">
                                    Setujui
                                  </button>
                                  <button onClick={() => rejectWithdraw(wd.id, wd.userId, wd.amount)} className="bg-red-500/20 text-red-400 px-3 py-1 rounded-lg text-xs">
                                    Tolak
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AdminWithdrawals
import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ref, get, update } from 'firebase/database'
import { db } from '../../config/firebase'
import Swal from 'sweetalert2'
import { formatRupiah } from '../../utils/format'

const AdminUsers = () => {
  const navigate = useNavigate()
  const [users, setUsers] = useState([])
  const [filteredUsers, setFilteredUsers] = useState([])
  const [searchQuery, setSearchQuery] = useState('')
  const [editingUser, setEditingUser] = useState(null)

  useEffect(() => {
    loadUsers()
  }, [])

  const loadUsers = async () => {
    const snap = await get(ref(db, 'users'))
    const usersData = snap.val() || {}
    const usersList = Object.entries(usersData).map(([uid, data]) => ({ uid, ...data }))
    usersList.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    setUsers(usersList)
    setFilteredUsers(usersList)
  }

  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase()
    setSearchQuery(query)
    if (!query) {
      setFilteredUsers(users)
    } else {
      setFilteredUsers(users.filter(u => 
        (u.username || '').toLowerCase().includes(query) || 
        (u.email || '').toLowerCase().includes(query)
      ))
    }
  }

  const openEditModal = (user) => {
    setEditingUser({ ...user })
  }

  const closeEditModal = () => {
    setEditingUser(null)
  }

  const saveUserEdit = async () => {
    if (!editingUser) return
    await update(ref(db, `users/${editingUser.uid}`), {
      level: editingUser.level,
      saldo: editingUser.saldo
    })
    Swal.fire({ icon: 'success', title: 'Berhasil!', timer: 1500, showConfirmButton: false, background: '#1c1c1e', color: 'white' })
    closeEditModal()
    loadUsers()
  }

  const toggleBan = async (uid, currentBanStatus) => {
    const newStatus = !currentBanStatus
    const result = await Swal.fire({
      title: newStatus ? 'Blokir User?' : 'Buka Blokir?',
      text: `Yakin ingin ${newStatus ? 'memblokir' : 'membuka blokir'} user ini?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#0A84FF',
      confirmButtonText: 'Ya',
      cancelButtonText: 'Batal',
      background: '#1c1c1e',
      color: 'white'
    })
    if (result.isConfirmed) {
      await update(ref(db, `users/${uid}`), { banned: newStatus })
      loadUsers()
      Swal.fire({ icon: 'success', title: 'Berhasil!', timer: 1500, showConfirmButton: false, background: '#1c1c1e', color: 'white' })
    }
  }

  return (
    <div className="bg-black min-h-screen">
      <div className="flex">
        {/* Sidebar */}
        <div className="fixed left-0 top-0 w-[260px] h-screen bg-black/80 backdrop-blur-2xl border-r border-white/10 z-50">
          <div className="p-6 border-b border-white/10 flex items-center gap-3">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0A84FF" strokeWidth="2">
              <path d="M4 16L9 11L13 15L20 8"/>
              <path d="M16 8H20V12"/>
            </svg>
            <span className="text-lg font-black">Refcuan Admin</span>
          </div>
          <div className="py-4">
            <a onClick={() => navigate('/admin')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 10L12 3L21 10V20H14V14H10V20H3V10Z"/></svg>
              <span>Dashboard</span>
            </a>
            <a onClick={() => navigate('/admin/users')} className="flex items-center gap-3 px-6 py-3 text-white bg-blue-500/10 border-l-3 border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              <span>Kelola User</span>
            </a>
            <a onClick={() => navigate('/admin/withdrawals')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              <span>Kelola Withdraw</span>
            </a>
            <a onClick={() => navigate('/admin/settings')} className="flex items-center gap-3 px-6 py-3 text-[#8E8E93] hover:bg-blue-500/10 hover:text-[#0A84FF] border-l-3 border-transparent hover:border-blue-500 cursor-pointer">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              <span>Settings</span>
            </a>
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-5 border-t border-white/10">
            <div className="bg-red-500/20 px-3 py-2 rounded-full text-center">
              <span className="text-[10px] font-bold text-red-400">ADMIN REFCUAN</span>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="ml-[260px] w-full">
          <div className="sticky top-0 bg-black/60 backdrop-blur-xl border-b border-white/10 p-4 flex justify-between items-center z-50">
            <span className="font-bold text-lg">Kelola User</span>
            <button onClick={() => { sessionStorage.removeItem('admin_logged'); navigate('/admin/login'); }} className="bg-red-500/20 px-4 py-2 rounded-xl text-red-400 text-sm font-bold">
              Keluar
            </button>
          </div>

          <div className="p-6">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <input
                type="text"
                placeholder="Cari user berdasarkan username atau email..."
                value={searchQuery}
                onChange={handleSearch}
                className="w-full max-w-md px-5 py-3 rounded-full bg-white/5 border border-white/10 text-white outline-none focus:border-blue-500 mb-6"
              />
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/10">
                      <th className="p-3 text-left text-[11px] text-gray-500">Username</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Email</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Level</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Total Ref</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Total Komisi</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Status</th>
                      <th className="p-3 text-left text-[11px] text-gray-500">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr key={user.uid} className="border-b border-white/5">
                        <td className="p-3">{user.username || '-'}</td>
                        <td className="p-3">{user.email || '-'}</td>
                        <td className="p-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                            user.level === 'PREMIUM' ? 'bg-purple-500/20 text-purple-400' :
                            user.level === 'VIP' ? 'bg-red-500/20 text-red-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>
                            {user.level || 'FREE'}
                          </span>
                        </td>
                        <td className="p-3">{user.totalReferrals || 0}</td>
                        <td className="p-3 font-mono text-blue-400">{formatRupiah(user.totalKomisi || 0)}</td>
                        <td className="p-3">
                          <span className={user.banned ? 'text-red-400' : 'text-green-400'}>
                            {user.banned ? 'BANNED' : 'AKTIF'}
                          </span>
                        </td>
                        <td className="p-3">
                          <button onClick={() => openEditModal(user)} className="bg-blue-500/20 text-blue-400 px-3 py-1 rounded-lg text-xs mr-2">
                            Edit
                          </button>
                          <button onClick={() => toggleBan(user.uid, user.banned)} className="bg-red-500/20 text-red-400 px-3 py-1 rounded-lg text-xs">
                            {user.banned ? 'Unban' : 'Ban'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      {editingUser && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[200]">
          <div className="bg-[#1c1c1e] rounded-3xl p-6 w-full max-w-md">
            <h3 className="font-bold text-lg mb-4">Edit User</h3>
            <select
              value={editingUser.level || 'FREE'}
              onChange={(e) => setEditingUser({ ...editingUser, level: e.target.value })}
              className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mb-4"
            >
              <option value="FREE">FREE</option>
              <option value="PREMIUM">PREMIUM</option>
              <option value="VIP">VIP</option>
            </select>
            <input
              type="number"
              placeholder="Saldo"
              value={editingUser.saldo || 0}
              onChange={(e) => setEditingUser({ ...editingUser, saldo: parseInt(e.target.value) || 0 })}
              className="w-full p-4 rounded-2xl bg-white/5 border border-white/10 text-white mb-4"
            />
            <div className="flex gap-3">
              <button onClick={saveUserEdit} className="flex-1 bg-blue-500 py-3 rounded-xl font-bold">Simpan</button>
              <button onClick={closeEditModal} className="flex-1 bg-gray-600 py-3 rounded-xl font-bold">Batal</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminUsers
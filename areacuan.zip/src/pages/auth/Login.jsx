import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../../config/firebase'
import Swal from 'sweetalert2'
import GlassCard from '../../components/UI/GlassCard'
import InputIOS from '../../components/UI/InputIOS'
import ButtonIOS from '../../components/UI/ButtonIOS'

const Login = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!email || !password) {
      Swal.fire({ icon: 'error', title: 'Oops!', text: 'Email dan password wajib diisi!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }

    setLoading(true)

    try {
      await signInWithEmailAndPassword(auth, email, password)
      Swal.fire({ icon: 'success', title: 'Login Berhasil!', text: 'Mengalihkan...', timer: 1500, showConfirmButton: false, background: '#FFFFFF', color: '#1C1C1E' })
      setTimeout(() => navigate('/'), 1500)
    } catch (error) {
      let msg = 'Login gagal. Periksa email/password.'
      if (error.code === 'auth/user-not-found') msg = 'Email tidak terdaftar.'
      if (error.code === 'auth/wrong-password') msg = 'Password salah.'
      if (error.code === 'auth/invalid-email') msg = 'Format email tidak valid.'
      Swal.fire({ icon: 'error', title: 'Login Gagal', text: msg, background: '#FFFFFF', color: '#1C1C1E' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-5">
      <GlassCard className="max-w-md w-full p-8 animate-ios">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-[24px] bg-gradient-to-br from-[#007AFF] to-[#5AC8FA] flex items-center justify-center mx-auto shadow-[0_10px_30px_rgba(0,122,255,0.3)]">
            <svg width="38" height="38" viewBox="0 0 24 24" fill="none">
              <path d="M4 16L9 11L13 15L20 8" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
              <path d="M16 8H20V12" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
            </svg>
          </div>
          <h1 className="text-3xl font-black mt-4 text-[#1C1C1E]">Refcuan</h1>
          <p className="text-[#8E8E93] mt-2">Login ke akun referral Anda</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <InputIOS type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <InputIOS type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <ButtonIOS type="submit" variant="primary" className="w-full h-14 mt-6" disabled={loading}>
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto"></div> : 'Masuk'}
          </ButtonIOS>
        </form>

        <div className="flex items-center my-8">
          <div className="flex-1 h-px bg-[#E5E5EA]"></div>
          <span className="px-4 text-[#8E8E93] text-sm">atau</span>
          <div className="flex-1 h-px bg-[#E5E5EA]"></div>
        </div>

        <div className="text-center">
          <span className="text-[#8E8E93]">Belum punya akun? </span>
          <Link to="/register" className="text-[#007AFF] font-semibold">Daftar</Link>
        </div>
      </GlassCard>
    </div>
  )
}

export default Login
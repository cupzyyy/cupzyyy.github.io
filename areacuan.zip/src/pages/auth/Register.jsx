import React, { useState, useEffect } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'
import { createUserWithEmailAndPassword } from 'firebase/auth'
import { ref, set, get } from 'firebase/database'
import { auth, db } from '../../config/firebase'
import Swal from 'sweetalert2'
import GlassCard from '../../components/UI/GlassCard'
import InputIOS from '../../components/UI/InputIOS'
import ButtonIOS from '../../components/UI/ButtonIOS'

const Register = () => {
  const [searchParams] = useSearchParams()
  const [formData, setFormData] = useState({
    username: '',
    phone: '',
    email: '',
    password: '',
    confirmPassword: '',
    bankType: '',
    accountNumber: '',
    accountName: ''
  })
  const [captcha, setCaptcha] = useState('')
  const [captchaInput, setCaptchaInput] = useState('')
  const [referrer, setReferrer] = useState(null)
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const refCode = searchParams.get('ref')

  const generateCaptcha = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    let code = ''
    for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)]
    setCaptcha(code)
  }

  useEffect(() => {
    generateCaptcha()
    if (refCode) {
      loadReferrer()
    }
  }, [refCode])

  const loadReferrer = async () => {
    const usersRef = ref(db, 'users')
    const snapshot = await get(usersRef)
    const users = snapshot.val() || {}
    for (const uid in users) {
      if (users[uid].referralCode === refCode) {
        setReferrer(users[uid])
        break
      }
    }
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const { username, phone, email, password, confirmPassword, bankType, accountNumber, accountName } = formData

    if (!username || !phone || !email || !password || !confirmPassword || !bankType || !accountNumber || !accountName || !captchaInput) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Semua field wajib diisi!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }
    if (password !== confirmPassword) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Password tidak cocok!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }
    if (password.length < 6) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Password min 6 karakter!', background: '#FFFFFF', color: '#1C1C1E' })
      return
    }
    if (captchaInput.toUpperCase() !== captcha) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: 'Kode captcha salah!', background: '#FFFFFF', color: '#1C1C1E' })
      generateCaptcha()
      return
    }

    setLoading(true)

    try {
      const userCred = await createUserWithEmailAndPassword(auth, email, password)
      const uid = userCred.user.uid
      const referralCode = 'RFC' + Math.random().toString(36).substring(2, 8).toUpperCase()
      const referralLink = `${window.location.origin}/register?ref=${referralCode}`

      let komisi = 200
      if (referrer?.level === 'PREMIUM') komisi = 3000
      if (referrer?.level === 'VIP') komisi = 5000

      await set(ref(db, `users/${uid}`), {
        uid, username, phone, email, bankType, accountNumber, accountName,
        saldo: 0, totalKomisi: 0, totalReferrals: 0, level: 'FREE',
        referralCode, referralLink,
        referredBy: refCode || null, referredByUsername: referrer?.username || null,
        createdAt: new Date().toISOString(), banned: false
      })

      if (refCode && referrer) {
        await set(ref(db, `referrals/${referrer.uid}/${uid}`), { uid, username, email, referredAt: new Date().toISOString() })
        
        const refSnap = await get(ref(db, `users/${referrer.uid}`))
        const refData = refSnap.val()
        
        await set(ref(db, `users/${referrer.uid}`), {
          ...refData,
          saldo: (refData?.saldo || 0) + komisi,
          totalKomisi: (refData?.totalKomisi || 0) + komisi,
          totalReferrals: (refData?.totalReferrals || 0) + 1
        })
        
        const commissionsRef = ref(db, `commissions/${referrer.uid}`)
        const newCommRef = await push(commissionsRef)
        await set(newCommRef, {
          referredEmail: email, amount: komisi, level: referrer.level || 'FREE', createdAt: new Date().toISOString()
        })
      }

      Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Pendaftaran sukses!', timer: 1800, showConfirmButton: false, background: '#FFFFFF', color: '#1C1C1E' })
      setTimeout(() => navigate('/login'), 1800)
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: err.code === 'auth/email-already-in-use' ? 'Email sudah terdaftar!' : 'Terjadi kesalahan', background: '#FFFFFF', color: '#1C1C1E' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-5">
      <GlassCard className="max-w-md w-full p-6 animate-ios" style={{ maxHeight: '95vh', overflowY: 'auto' }}>
        <div className="text-center mb-6">
          <div className="w-20 h-20 rounded-[24px] bg-gradient-to-br from-[#007AFF] to-[#5AC8FA] flex items-center justify-center mx-auto shadow-lg">
            <svg width="38" height="38" viewBox="0 0 24 24" fill="none">
              <path d="M4 16L9 11L13 15L20 8" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
              <path d="M16 8H20V12" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
            </svg>
          </div>
          <h1 className="text-2xl font-black text-[#1C1C1E] mt-3">Daftar Akun</h1>
          <p className="text-[#8E8E93] text-sm mt-1">Dapatkan komisi hingga Rp5.000 per referral</p>
        </div>

        {referrer && (
          <div className="bg-[#F2F2F7] border-l-3 border-[#007AFF] rounded-2xl p-3 mb-5 text-sm">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2" style={{ display: 'inline', marginRight: '6px' }}>
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
            Mendaftar melalui referral: <strong className="text-[#007AFF]">{referrer.username}</strong>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              <span className="text-[11px] font-bold tracking-[2px] text-[#007AFF] uppercase">DATA AKUN</span>
            </div>
            <div className="space-y-3">
              <InputIOS name="username" placeholder="Username" value={formData.username} onChange={handleChange} />
              <InputIOS name="phone" type="tel" placeholder="Nomor Telepon" value={formData.phone} onChange={handleChange} />
              <InputIOS name="email" type="email" placeholder="Email" value={formData.email} onChange={handleChange} />
              <InputIOS name="password" type="password" placeholder="Password (min. 6 karakter)" value={formData.password} onChange={handleChange} />
              <InputIOS name="confirmPassword" type="password" placeholder="Konfirmasi Password" value={formData.confirmPassword} onChange={handleChange} />
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              <span className="text-[11px] font-bold tracking-[2px] text-[#007AFF] uppercase">DATA REKENING</span>
            </div>
            <div className="space-y-3">
              <select name="bankType" value={formData.bankType} onChange={handleChange} className="w-full h-[56px] rounded-[20px] px-[18px] outline-none text-[#1C1C1E] bg-[#F9F9FB] border border-[#E5E5EA] appearance-none">
                <option value="">Pilih Metode Penarikan</option>
                <optgroup label="🏦 Bank Transfer">
                  <option>BCA</option><option>Mandiri</option><option>BRI</option><option>BNI</option>
                </optgroup>
                <optgroup label="📱 E-Wallet">
                  <option>DANA</option><option>OVO</option><option>GoPay</option>
                </optgroup>
              </select>
              <InputIOS name="accountNumber" placeholder="Nomor Rekening / E-Wallet" value={formData.accountNumber} onChange={handleChange} />
              <InputIOS name="accountName" placeholder="Nama Pemilik Rekening" value={formData.accountName} onChange={handleChange} />
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="12" cy="12" r="2"/></svg>
              <span className="text-[11px] font-bold tracking-[2px] text-[#007AFF] uppercase">VERIFIKASI</span>
            </div>
            <div className="bg-[#F2F2F7] rounded-2xl p-5 text-center">
              <div className="flex items-center justify-center gap-4 mb-4 flex-wrap">
                <span className="font-mono text-[28px] font-black tracking-[8px] bg-white p-4 rounded-2xl text-[#007AFF]">{captcha.split('').join(' ')}</span>
                <button type="button" onClick={generateCaptcha} className="w-12 h-12 rounded-xl bg-white border border-[#E5E5EA] flex items-center justify-center">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#007AFF" strokeWidth="2">
                    <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M20.49 15a9 9 0 0 1-14.85 3.36L1 14"/>
                  </svg>
                </button>
              </div>
              <InputIOS placeholder="Kode 6 digit" maxLength="6" value={captchaInput} onChange={(e) => setCaptchaInput(e.target.value)} className="text-center tracking-[4px]" />
            </div>
          </div>

          <ButtonIOS type="submit" variant="primary" className="w-full py-3.5" disabled={loading}>
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto"></div> : 'Daftar Sekarang'}
          </ButtonIOS>
        </form>

        <div className="text-center mt-5 pt-3 border-t border-[#E5E5EA]">
          <p className="text-[#8E8E93] text-sm">Sudah punya akun? <Link to="/login" className="text-[#007AFF] font-semibold">Masuk</Link></p>
          <Link to="/" className="text-[#C6C6C8] text-xs mt-2 inline-block">← Kembali ke Beranda</Link>
        </div>
      </GlassCard>
    </div>
  )
}

export default Register
const API_BASE = '/api'

export const createPayment = async (data) => {
  try {
    const response = await fetch(`${API_BASE}/create-payment.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    return await response.json()
  } catch (error) {
    console.error('API Error:', error)
    throw error
  }
}

export const checkPaymentStatus = async (orderId) => {
  try {
    const response = await fetch(`${API_BASE}/check-status.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order_id: orderId })
    })
    return await response.json()
  } catch (error) {
    console.error('API Error:', error)
    throw error
  }
}

export const withdrawViaAPI = async (data) => {
  try {
    const response = await fetch(`${API_BASE}/withdraw.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    return await response.json()
  } catch (error) {
    console.error('API Error:', error)
    throw error
  }
}

export default {
  createPayment,
  checkPaymentStatus,
  withdrawViaAPI
}
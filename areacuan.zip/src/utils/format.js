export const formatRupiah = (amount) => {
  return 'Rp ' + (amount || 0).toLocaleString('id-ID')
}

export const formatDate = (dateString) => {
  if (!dateString) return '-'
  return new Date(dateString).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })
}

export const formatDateTime = (dateString) => {
  if (!dateString) return '-'
  return new Date(dateString).toLocaleString('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

export const generateId = (prefix = 'RFC') => {
  return prefix + '-' + Date.now() + '-' + Math.random().toString(36).substring(2, 8).toUpperCase()
}
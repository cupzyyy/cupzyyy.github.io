import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import Layout from './components/Layout/Layout'
import ProtectedRoute from './components/Layout/ProtectedRoute'

// Auth Pages
import Login from './pages/auth/Login'
import Register from './pages/auth/Register'

// User Pages
import Dashboard from './pages/user/Dashboard'
import Referral from './pages/user/Referral'
import Riwayat from './pages/user/Riwayat'
import Upgrade from './pages/user/Upgrade'
import Profile from './pages/user/Profile'
import Withdraw from './pages/user/Withdraw'
import Payment from './pages/user/Payment'
import ProfileInfo from './pages/user/ProfileInfo'
import ProfileBank from './pages/user/ProfileBank'
import ProfilePassword from './pages/user/ProfilePassword'
import ProfileReferralCode from './pages/user/ProfileReferralCode'

// About Page
import About from './pages/about/About'

// Admin Pages
import AdminLogin from './pages/admin/AdminLogin'
import AdminDashboard from './pages/admin/AdminDashboard'
import AdminUsers from './pages/admin/AdminUsers'
import AdminWithdrawals from './pages/admin/AdminWithdrawals'
import AdminSettings from './pages/admin/AdminSettings'

function App() {
  return (
    <AuthProvider>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin/login" element={<AdminLogin />} />

        {/* User Protected Routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/referral" element={
          <ProtectedRoute>
            <Layout>
              <Referral />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/riwayat" element={
          <ProtectedRoute>
            <Layout>
              <Riwayat />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/upgrade" element={
          <ProtectedRoute>
            <Layout>
              <Upgrade />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/profile" element={
          <ProtectedRoute>
            <Layout>
              <Profile />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/withdraw" element={
          <ProtectedRoute>
            <Layout>
              <Withdraw />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/payment" element={
          <ProtectedRoute>
            <Payment />
          </ProtectedRoute>
        } />
        <Route path="/profile/info" element={
          <ProtectedRoute>
            <Layout>
              <ProfileInfo />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/profile/bank" element={
          <ProtectedRoute>
            <Layout>
              <ProfileBank />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/profile/password" element={
          <ProtectedRoute>
            <Layout>
              <ProfilePassword />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/profile/referral-code" element={
          <ProtectedRoute>
            <Layout>
              <ProfileReferralCode />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/about" element={
          <ProtectedRoute>
            <Layout>
              <About />
            </Layout>
          </ProtectedRoute>
        } />

        {/* Admin Protected Routes */}
        <Route path="/admin" element={
          <ProtectedRoute requireAdmin={true}>
            <AdminDashboard />
          </ProtectedRoute>
        } />
        <Route path="/admin/users" element={
          <ProtectedRoute requireAdmin={true}>
            <AdminUsers />
          </ProtectedRoute>
        } />
        <Route path="/admin/withdrawals" element={
          <ProtectedRoute requireAdmin={true}>
            <AdminWithdrawals />
          </ProtectedRoute>
        } />
        <Route path="/admin/settings" element={
          <ProtectedRoute requireAdmin={true}>
            <AdminSettings />
          </ProtectedRoute>
        } />
      </Routes>
    </AuthProvider>
  )
}

export default App
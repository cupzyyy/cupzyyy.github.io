import { useState, useEffect, createContext, useContext } from 'react'
import { auth, db } from '../config/firebase'
import { onAuthStateChanged, signOut } from 'firebase/auth'
import { ref, onValue, off } from 'firebase/database'

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [userData, setUserData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser)
      
      if (firebaseUser) {
        const userRef = ref(db, `users/${firebaseUser.uid}`)
        const unsubscribeData = onValue(userRef, (snapshot) => {
          setUserData(snapshot.val())
          setLoading(false)
        }, (err) => {
          setError(err)
          setLoading(false)
        })
        
        return () => unsubscribeData()
      } else {
        setUserData(null)
        setLoading(false)
      }
    })

    return () => unsubscribe()
  }, [])

  const logout = async () => {
    try {
      await signOut(auth)
      return true
    } catch (err) {
      setError(err)
      return false
    }
  }

  const value = {
    user,
    userData,
    loading,
    error,
    logout,
    setUserData
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}
import { useState, useEffect, useCallback } from 'react'
import { ref, get, update, onValue } from 'firebase/database'
import { db } from '../config/firebase'
import { useAuth } from './useAuth'

export const useUserData = () => {
  const { user } = useAuth()
  const [userData, setUserData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!user) {
      setUserData(null)
      setLoading(false)
      return
    }

    const userRef = ref(db, `users/${user.uid}`)
    const unsubscribe = onValue(userRef, (snapshot) => {
      setUserData(snapshot.val())
      setLoading(false)
    }, (err) => {
      setError(err)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [user])

  const updateUserData = useCallback(async (updates) => {
    if (!user) throw new Error('User not authenticated')
    
    try {
      const userRef = ref(db, `users/${user.uid}`)
      await update(userRef, updates)
      return true
    } catch (err) {
      setError(err)
      return false
    }
  }, [user])

  const getLevelKomisi = useCallback(() => {
    const level = userData?.level || 'FREE'
    switch (level) {
      case 'VIP': return 5000
      case 'PREMIUM': return 3000
      default: return 200
    }
  }, [userData])

  const getLevelName = useCallback(() => {
    return userData?.level || 'FREE'
  }, [userData])

  const getTotalReferrals = useCallback(async () => {
    if (!userData?.referralCode) return 0
    
    try {
      const usersRef = ref(db, 'users')
      const snapshot = await get(usersRef)
      const users = snapshot.val() || {}
      let count = 0
      for (const uid in users) {
        if (users[uid].referredBy === userData.referralCode) {
          count++
        }
      }
      return count
    } catch (err) {
      setError(err)
      return 0
    }
  }, [userData])

  const getReferralsList = useCallback(async () => {
    if (!userData?.referralCode) return []
    
    try {
      const usersRef = ref(db, 'users')
      const snapshot = await get(usersRef)
      const users = snapshot.val() || {}
      const referrals = []
      for (const uid in users) {
        if (users[uid].referredBy === userData.referralCode) {
          referrals.push({
            uid,
            username: users[uid].username || 'User',
            email: users[uid].email,
            referredAt: users[uid].referredAt || users[uid].createdAt
          })
        }
      }
      return referrals.sort((a, b) => new Date(b.referredAt) - new Date(a.referredAt))
    } catch (err) {
      setError(err)
      return []
    }
  }, [userData])

  const getCommissions = useCallback(async () => {
    if (!user) return []
    
    try {
      const commissionsRef = ref(db, `commissions/${user.uid}`)
      const snapshot = await get(commissionsRef)
      const data = snapshot.val() || {}
      return Object.entries(data).map(([key, val]) => ({ id: key, ...val }))
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } catch (err) {
      setError(err)
      return []
    }
  }, [user])

  const getWithdrawals = useCallback(async () => {
    if (!user) return []
    
    try {
      const withdrawalsRef = ref(db, `withdrawals/${user.uid}`)
      const snapshot = await get(withdrawalsRef)
      const data = snapshot.val() || {}
      return Object.entries(data).map(([key, val]) => ({ id: key, ...val }))
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } catch (err) {
      setError(err)
      return []
    }
  }, [user])

  const requestWithdraw = useCallback(async (amount, bankData) => {
    if (!user) throw new Error('User not authenticated')
    if (amount < 50000) throw new Error('Minimal withdraw Rp50.000')
    if ((userData?.saldo || 0) < amount) throw new Error('Saldo tidak mencukupi')

    const fee = Math.floor(amount * 0.1)
    const netAmount = amount - fee
    const wid = `WD-${Date.now()}`
    const now = new Date().toISOString()

    try {
      const withdrawData = {
        id: wid,
        amount,
        fee,
        netAmount,
        bankType: bankData.bankType || userData?.bankType,
        accountNumber: bankData.accountNumber || userData?.accountNumber,
        accountName: bankData.accountName || userData?.accountName,
        status: 'pending',
        createdAt: now,
        username: userData?.username,
        email: user?.email
      }

      await update(ref(db, `withdrawals/${user.uid}/${wid}`), withdrawData)
      await update(ref(db, `allWithdrawals/${wid}`), { ...withdrawData, userId: user.uid })
      await update(ref(db, `users/${user.uid}/saldo`), (userData?.saldo || 0) - amount)
      
      return { success: true, wid }
    } catch (err) {
      setError(err)
      return { success: false, error: err.message }
    }
  }, [user, userData])

  return {
    userData,
    loading,
    error,
    updateUserData,
    getLevelKomisi,
    getLevelName,
    getTotalReferrals,
    getReferralsList,
    getCommissions,
    getWithdrawals,
    requestWithdraw
  }
}
import { useState, useCallback } from 'react'

export const useToast = () => {
  const [toast, setToast] = useState(null)

  const showToast = useCallback((message, type = 'info') => {
    setToast({ message, type })
    setTimeout(() => {
      setToast(null)
    }, 3000)
  }, [])

  const ToastComponent = () => {
    if (!toast) return null
    
    const bgColor = toast.type === 'success' ? '#34C759' : 
                     toast.type === 'error' ? '#FF3B30' : '#1C1C1E'

    return (
      <div
        style={{
          position: 'fixed',
          bottom: '90px',
          left: '50%',
          transform: 'translateX(-50%)',
          background: bgColor,
          color: 'white',
          padding: '12px 20px',
          borderRadius: '60px',
          fontSize: '13px',
          fontWeight: 500,
          zIndex: 1000,
          animation: 'slideUp 0.3s ease',
          whiteSpace: 'nowrap'
        }}
      >
        {toast.message}
      </div>
    )
  }

  return { showToast, ToastComponent }
}